package seznam.prostredky;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author karel@simerda.cz
 */
public class ProstredekTest implements Cloneable {

// TODO Postupně aktivujte testovací metody    
    
    
    Prostredek oa1 = new Prostredek(
            TypyDopravnichProstredku.OSOBNI_AUTOMOBIL, 1000, "ABCD") {
    };

    Prostredek oa2 = new Prostredek(
            TypyDopravnichProstredku.OSOBNI_AUTOMOBIL, 1000, "ABCD") {
    };

    Prostredek oa3 = new Prostredek(
            TypyDopravnichProstredku.OSOBNI_AUTOMOBIL, 1000, "DCBA") {
    };

    Prostredek na1 = new Prostredek(
            TypyDopravnichProstredku.NAKLADNI_AUTOMOBIL, 1000, "ABCD") {
    };

    Prostredek na2 = new Prostredek(
            TypyDopravnichProstredku.NAKLADNI_AUTOMOBIL, 1000, "DCBA") {
    };

    public ProstredekTest() {
    }

    @Test
    public void testGetTyp() {
        assertEquals(TypyDopravnichProstredku.OSOBNI_AUTOMOBIL, oa1.getTyp());
    }

    // TODO Proč musí být při porovnání hodnoty hmotnosti zadán třetí argument?
    @Test
    public void testGetHmotnost() {
        assertEquals(1000, oa1.getHmotnost(), 0.00000001);
    }

    @Test
    public void testGetSpz() {
        assertEquals("ABCD", oa1.getSpz());
    }

    @Test
    public void testToString() {
         assertEquals("typ=osobní auto, SPZ=ABCD, hmotnost=1000.00", oa1.toString());
    }

    @Test
    public void test05_01_Equals() {
        assertTrue(oa1.equals(oa1));
    }

    // TODO Proč je očekávaná neshoda, když instance oa1 a oa2 mají stejný stav?
    @Test
    public void test05_02_Equals() {
        assertFalse(oa1.equals(oa2));
    }

    @Test
    public void test05_03_Equals() {
        assertFalse(oa1.equals(oa3));
    }

    @Test
    public void test05_07_Equals() {
        assertFalse(oa1.equals(null));
    }

    @Test
    public void test05_08_Equals() {
        assertFalse(oa1.equals(new Object()));
    }

    @Test
    public void test06_01_HashCode() {

        assertTrue(oa1.hashCode() == oa2.hashCode());
    }

    @Test
    public void test06_02_HashCode() {

        assertFalse(oa1.hashCode() == oa3.hashCode());
    }

    @Test
    public void test06_03_HashCode() {
        assertFalse(oa1.hashCode() == na1.hashCode());
    }

}
