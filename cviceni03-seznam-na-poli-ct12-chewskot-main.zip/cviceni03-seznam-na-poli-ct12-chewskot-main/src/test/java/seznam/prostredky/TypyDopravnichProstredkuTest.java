package seznam.prostredky;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author karel@simerda.cz
 */
public class TypyDopravnichProstredkuTest {

    public TypyDopravnichProstredkuTest() {
    }
// TODO Postupně aktivujte testovací metody     
//
    @Test
    public void testValues() {
        TypyDopravnichProstredku[] typy = TypyDopravnichProstredku.values();
        assertEquals(3, typy.length);
    }

    @Test
    public void testValueOf() {
        TypyDopravnichProstredku typ = TypyDopravnichProstredku.valueOf("OSOBNI_AUTOMOBIL");
        assertEquals(TypyDopravnichProstredku.OSOBNI_AUTOMOBIL, typ);
    }

    @Test
    public void testNazevTruck() {
        TypyDopravnichProstredku typ = TypyDopravnichProstredku.NAKLADNI_AUTOMOBIL;
        assertEquals("truck", typ.nazev());
    }

    @Test
    public void testNazevOsobni() {
        TypyDopravnichProstredku typ = TypyDopravnichProstredku.OSOBNI_AUTOMOBIL;
        assertEquals("osobní auto", typ.nazev());
    }

    @Test
    public void testNazevTraktor() {
        TypyDopravnichProstredku typ = TypyDopravnichProstredku.TRAKTOR;
        assertEquals("traktor", typ.nazev());
    }

    @Test
    public void test01ToString() {
        String a = TypyDopravnichProstredku.NAKLADNI_AUTOMOBIL.toString();
        assertEquals("truck", a);
    }

    @Test
    public void test02ToString() {
        String a = TypyDopravnichProstredku.OSOBNI_AUTOMOBIL.toString();
        assertEquals("osobní auto", a);
    }

    @Test
    public void test03ToString() {
        String a = TypyDopravnichProstredku.TRAKTOR.toString();
        assertEquals("traktor", a);
    }

}
