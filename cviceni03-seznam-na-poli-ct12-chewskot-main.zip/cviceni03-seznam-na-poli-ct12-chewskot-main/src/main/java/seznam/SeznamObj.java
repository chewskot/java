/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seznam;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *
 * @author karel@simerda.cz
 */
// TODO v generické třídě není vhodné používat takový konkrétní pojem jako je objekt
public class SeznamObj<E> implements Seznam<E> {

    private E[] pole;
    private int pocet;

    public SeznamObj(int kapacita) throws IllegalArgumentException {
        if (kapacita < 1) {
            throw new IllegalArgumentException();
        }

        this.pole = (E[])new Object[kapacita];
        this.pocet = 0;
    }

    @Override
    public E dej(int pozice) throws IndexOutOfBoundsException, IllegalAccessError {
        // TODO duplicita
        if (this.pocet == 0) {
            throw new IllegalAccessError("Chyba! Seznam je prázdný.");
        }
        // TODO není dobré měnit proměnné v podmíce
        // TODO duplicita v kódu
        if (--pozice < 0 || pozice > this.pocet - 1) {
            throw new IndexOutOfBoundsException("Chyba! Index je mimo rozsah.");
        }
        // TODO zbytečná lokální proměnná
        E objekt = this.pole[pozice];

        return objekt;
    }

    @Override
    // TODO přejmenovat i v rozhraní
    public E[] dejObjekty() {
        E[] sp = (E[]) new Object[pocet];
        System.arraycopy(pole, 0, sp, 0, pocet);
        return sp;
    }

    @Override
    // TODO přejmenovat i v rozhraní
    public E[] dejKopieObjektu() throws CloneNotSupportedException {
        E[] sp = dejObjekty();
        E[] spCopy = (E[]) new Object[pocet];
        System.arraycopy(sp, 0, spCopy, 0, pocet);
        return sp;
    }

    @Override
    public E odeber(int pozice) throws IndexOutOfBoundsException, IllegalAccessError {
        if (this.pocet == 0) {
            throw new IllegalAccessError("Chyba! Seznam je prázdný.");
        }
        // TODO není dobré měnit proměnné v podmíce
        // TODO duplicita v kódu
        if (--pozice < 0 || pozice > this.pocet - 1) {
            throw new IndexOutOfBoundsException("Chyba! Index je mimo rozsah.");
        }

        E objekt = this.pole[pozice];
        this.pole[pozice] = null;

        //  TODO zmenšuje se když je potřeba a ne vždy
        //  TODO zmenšování, zvětšování a posun řešte samostatnými metodami nebo jedním příkazem System.arraycopy
        E[] novePole;
        if (--this.pocet < this.pole.length / 4) {
            novePole = (E[]) new Object[this.pole.length / 2];
        } else {
            novePole = (E[]) new Object[this.pole.length];
        }

        int index = 0;
        for (E item : this.pole) {
            if (item != null) {
                novePole[index++] = item;
            }
            if (index == this.pocet) {
                break;
            }
        }

        this.pole = novePole;

        return objekt;
    }

    @Override
    public void vloz(E objekt) throws IllegalArgumentException {
        if (objekt == null) {
            throw new IllegalArgumentException();
        }

        E[] novePole;
        //  TODO zmenšuje se když je potřeba a ne vždy
        //  TODO zmenšování, zvětšování a posun řešte samostatnými metodami nebo jedním příkazem System.arraycopy
        if (++this.pocet > this.pole.length) {
            novePole = (E[]) new Object[this.pole.length * 2];
        } else {
            novePole = (E[]) new Object[this.pole.length];
        }

        int index = 0;
        for (E item : this.pole) {
            if (item != null) {
                novePole[index++] = item;
            }
            if (index == this.pocet) {
                break;
            }
        }

        novePole[this.pocet - 1] = objekt;
        this.pole = novePole;
    }

    @Override
    public int pocet() {
        return this.pocet;
    }

    @Override
    public int kapacita() {
        return this.pole.length;
    }

    @Override
    public void zrus() {
        this.pole = (E[]) new Object[kapacita()];
        this.pocet = 0;
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator() {
            int index = 0;

            @Override
            public boolean hasNext() {
                return index < pocet;
            }

            @Override
            public Object next() throws NoSuchElementException {
                if (hasNext()) {
                    return pole[index++];
                } else {
                    throw new NoSuchElementException();
                }
            }
        };
    }

}
