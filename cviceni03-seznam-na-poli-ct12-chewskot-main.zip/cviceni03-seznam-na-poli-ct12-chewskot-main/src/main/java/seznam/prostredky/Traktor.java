/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seznam.prostredky;

import java.util.Locale;

/**
 *
 * @author mojan
 */
public final class Traktor extends Prostredek {

    private double tah;

    public Traktor(String spz, double hmotnost, double tah) {
        super(TypyDopravnichProstredku.TRAKTOR, hmotnost, spz);

        if (tah <= 0) {
            throw new IllegalArgumentException();
        }

        this.tah = tah;
    }

    @Override
    public String toString() {
        return String.format(Locale.ENGLISH, "typ=%s, SPZ=%s, hmotnost=%5.2f, tah=%5.2f", getTyp().nazev(), getSpz(), getHmotnost(), getTah());
    }

    public double getTah() {
        return tah;
    }

}
