/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seznam.prostredky;

import java.util.Locale;

/**
 *
 * @author mojan
 */
public enum TypyDopravnichProstredku {
    NAKLADNI_AUTOMOBIL("truck"),
    OSOBNI_AUTOMOBIL("osobní auto"),
    TRAKTOR("traktor");

    private final String nazev;

    private TypyDopravnichProstredku(String nazev) {
        this.nazev = nazev;
    }

    public String nazev() {
        return nazev;
    }

    @Override
    public String toString() {
        return nazev;
    }

}
