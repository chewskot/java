/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seznam.prostredky;

import java.util.Locale;
import java.util.Objects;
import util.Barva;

/**
 *
 * @author mojan
 */
public final class OsobniAutomobil extends Prostredek {

    private Barva barva;
    private int pocetSedadel;

    public OsobniAutomobil(String spz, Barva barva, int pocetSedadel, double hmotnost) {
        super(TypyDopravnichProstredku.OSOBNI_AUTOMOBIL, hmotnost, spz);

        if (barva == null) {
            throw new NullPointerException();
        }
        if (pocetSedadel <= 0) {
            throw new IllegalArgumentException();
        }

        this.barva = barva;
        this.pocetSedadel = pocetSedadel;
    }

    @Override
    public int hashCode() {
        int hash = super.hashCode();
        hash = 97 * hash + Objects.hashCode(this.barva);
        hash = 97 * hash + this.pocetSedadel;
        return hash;
    }

    @Override
    public String toString() {
        return String.format(Locale.ENGLISH, "typ=%s, SPZ=%s, hmotnost=%5.2f,  barva=%s, početSedadel=%d", getTyp().nazev(), getSpz(), getHmotnost(), getBarva().getNazev(), getPocetSedadel());
    }

    public Barva getBarva() {
        return barva;
    }

    public int getPocetSedadel() {
        return pocetSedadel;
    }

}
