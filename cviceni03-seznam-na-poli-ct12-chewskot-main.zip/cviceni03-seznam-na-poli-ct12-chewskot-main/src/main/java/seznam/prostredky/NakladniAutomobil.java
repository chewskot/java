package seznam.prostredky;

import java.util.Locale;

/**
 *
 * @author karel@simerda.cz
 */
public final class NakladniAutomobil extends Prostredek {

    private int pocetNaprav;

    public NakladniAutomobil(String spz, int pocetNaprav, double hmotnost) {
        super(TypyDopravnichProstredku.NAKLADNI_AUTOMOBIL, hmotnost, spz);

        if (pocetNaprav <= 0) {
            throw new IllegalArgumentException();
        }

        this.pocetNaprav = pocetNaprav;
    }

    @Override
    public int hashCode() {
        int hash = super.hashCode();
        hash = 97 * hash + this.pocetNaprav;
        return hash;
    }

    @Override
    public String toString() {
        return String.format(Locale.ENGLISH, "typ=%s, SPZ=%s, hmotnost=%5.2f, početNáprav=%d", getTyp().nazev(), getSpz(), getHmotnost(), getPocetNaprav());
    }

    public int getPocetNaprav() {
        return pocetNaprav;
    }

}
