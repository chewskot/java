package seznam.prostredky;

import java.util.Locale;
import java.util.Objects;

/**
 *
 * @author karel@simerda.cz
 */
// TODO Upravte třídu Prostredek podle vzoru s využitím kličového slova sealed
public abstract class Prostredek implements Cloneable {

    private final TypyDopravnichProstredku typ;
    private final double hmotnost;
    private final String spz;

    public Prostredek(TypyDopravnichProstredku typ, double hmotnost, String spz) {
        if (spz == null || typ == null) {
            throw new NullPointerException();
        }

        if (hmotnost <= 0 || spz.isBlank()) {
            throw new IllegalArgumentException();
        }

        this.typ = typ;
        this.hmotnost = hmotnost;
        this.spz = spz;
    }

    @Override
    public int hashCode() {
        int hash = 17;
        hash = 31 * hash + typ.hashCode();
        hash = 31 * hash + Double.hashCode(hmotnost);
        hash = 31 * hash + spz.hashCode();
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Prostredek other = (Prostredek) obj;
        return Objects.equals(this.spz, other.spz);
    }

    @Override
    public Prostredek clone() throws CloneNotSupportedException {
        return (Prostredek) super.clone();
    }

    public TypyDopravnichProstredku getTyp() {
        return typ;
    }

    public double getHmotnost() {
        return hmotnost;
    }

    public String getSpz() {
        return spz;
    }

    @Override
    public String toString() {
        return String.format("typ=%s, SPZ=%s, hmotnost=%.2f", typ.toString().toLowerCase(), spz, hmotnost);
    }

}
// Klíčové slovo sealed umožňuje předefinovat názvy potomků

// TODO Doplňte alespoň ještě jednoho potomka podle vlastního výběru.

