Postup prací     
 1. Otevřete projekt v NetBeans a přejmenujte projekt tak, že místo koncovky 
    Prijmeni vložíte svoje příjmení. Jenom přejmenovaný projekt bude hodnocen.
 2. V NetBeans z menu Window/Action Items nebo Ctrl-6 otevřte okno Action Items.
 3. Podle úkolů TODO, rozhraní Seznam (signatura a kontrakt) a testů 
    implementujte všechny chybějící třídy a výčty.
 4. Poté co všechny projdou testy, zkontrolujte pokrytí vašich tříd a upravte
    implementaci tak, aby všechny třídy a výčty byly 100% pokryty.
 5. Po získání plného pokrytí uložte projekt do repository (commit a push) do
    větve "main".
 6. Vytvořte v Netbeans z větve "main" novou větev "prostredek".
 7. V NetBeans se vraťte do větve "main" a pokračujte v těchto úpravách:
    - a. Upravíte rozhraní Seznam tak, že místo typu Prostredek použijete 
       typ (třídu) Object.
    - b. Kromě úpravy signatury taky upravíte kontrakt rozhraní Seznam 
       tj. nahradíte všude slovo prostředek slovem objekt.
    - c. Po změně rozhraní Seznam přejmenujete třídu SeznamProstredku na SeznamObj
       a upravíte  třídu podle změny rozhraní.
    - d. To samé provedete s testovací třídou. Opravy testu budou minimální, 
       ale velmi důležité na pochopení, jak funguje typ Object.
    - e. Ostatní třídy a výčty není nutné měnit.
    - f. Uložte projekt do repository (commit a push) ve větvi "main".
 8. Vytvořte v Netbeans z větve "main" novou větev "object".
 9. V NetBeans se vraťte do větve "main" a pokračujte v těchto úpravách:
    - a. Postup bude obdobný kroku 7.
    - b. Všude proveďte nahrazení typu Object generickým typem E.
    - c. Upravte i kontrakty.
    - d. Uložte projekt do repository (commit a push) ve větvi "main".
    
