package cz.upce.fei.boop.pujcovna.data;

import java.util.Scanner;

/**
 *
 * @author mojan
 */
public class Yachta extends Lod {

    public int getPocetMotoru() {
        return pocetMotoru;
    }

    public void setPocetMotoru(int pocetMotoru) {
        this.pocetMotoru = pocetMotoru;
    }

    @Override
    protected String additionalString() {
        return " pocet motoru= " + getPocetMotoru();
    }

    private int pocetMotoru;

    public Yachta(String jmeno, int rychlost, int pocetMist, int pocetMotoru, TypyLodi typ) {
        super(jmeno, rychlost, pocetMist, typ);
        if (pocetMotoru > 3) {
            System.out.println("neni mozne mit na yachte vice nez tri motory");

        } else if (pocetMotoru < 0) {
            System.out.println("yachta nemuze byt bez motoru");
        } else {
            this.pocetMotoru = pocetMotoru;
        }

    }

    public Yachta() {

        try {

            if (!super.getChyba()) {
                Scanner scan = new Scanner(System.in);
                super.setTyp(TypyLodi.YACHTA);

                System.out.println("zadejte pocet motoru");
                int k = Integer.parseInt(scan.nextLine());

                if (k > 6) {
                    System.out.println("neni mozne mit na yachte vice nez sest motoru");

                } else if (k < 0) {
                    System.out.println("yachta nemuze byt bez motoru");
                } else {
                    this.pocetMotoru = k;
                    System.out.println("uspesne jsi vlozil yachtu");
                }
            }

        } catch (NumberFormatException e) {
            System.out.println("nastala chyba v zadávání dat prosím opravte jí opetovným zadáním příkazu");
        }
    }

}
