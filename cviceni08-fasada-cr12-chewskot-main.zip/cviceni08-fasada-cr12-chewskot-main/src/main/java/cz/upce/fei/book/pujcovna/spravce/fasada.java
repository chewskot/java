/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cz.upce.fei.book.pujcovna.spravce;

import static cz.upce.fei.boop.pujcovna.command.Commands.seznam;
import cz.upce.fei.boop.pujcovna.data.Lod;
import cz.upce.fei.boop.pujcovna.data.Lodicka;
import cz.upce.fei.boop.pujcovna.data.Rybarska;
import cz.upce.fei.boop.pujcovna.data.Yachta;
import cz.upce.fei.boop.pujcovna.generator.Generator;
import cz.upce.fei.boop.pujcovna.kolekce.KolekceException;
import cz.upce.fei.boop.pujcovna.perzistence.binar;
import cz.upce.fei.boop.pujcovna.perzistence.textSoubor;
import java.util.Scanner;

/**
 *
 * @author mojan
 */
public class fasada implements fasadaIn {

    Scanner scan = new Scanner(System.in);

    @Override
    public void novy() throws KolekceException {
        System.out.println("budeme vytvaret lodicku,yachtu nebo rybarskou lod?");
        System.out.println("pro lodicku napiste l nebo lodicka");
        System.out.println("pro yachtu napiste y nebo yachta");
        System.out.println("pro rybarskou lod napiste r nebo rybarska");

        String n = scan.nextLine();
        switch (n) {
            case "l", "lodicka" -> {

                Lodicka ll = new Lodicka();
                seznam.vlozPosledni(ll);
                if (ll.getChyba()) {
                    seznam.odeberPosledni();
                }
            }
            case "y", "yachta" -> {

                Yachta y = new Yachta();
                seznam.vlozPosledni(y);
                if (y.getChyba()) {
                    seznam.odeberPosledni();
                }
            }
            case "r", "rybarska" -> {

                Rybarska r = new Rybarska();
                seznam.vlozPosledni(r);
                if (r.getChyba()) {
                    seznam.odeberPosledni();
                }
            }
            default -> {
            }
        }
    }

    @Override
    public void najdi() {
        if (seznam.getSize() == 0) {
            System.out.println("nelze hledat prvky v prázdném seznamu");
        } else {
            System.out.println("zadej ID pro nalezeni prvku");
            String n = scan.nextLine();
            Lod k = seznam.Najdi(seznam, Integer.parseInt(n));
            if (k == null) {
                System.out.println("pozadovena ID " + n + " neni v seznamu");
            } else {
                System.out.println(k);
            }

        }
    }

    @Override
    public void odeber() throws KolekceException {
        if (seznam.getSize() == 0) {
            System.out.println("nelze odebrat prvek, jelikož seznam je prazdny");
        } else {
            if (seznam.dejAkt()) {

                System.out.println(seznam.odeberAktualni() + "byl uspesne odebran");
            } else {
                System.out.println("neni nastaven aktualni prvek");
            }
        }
    }

    @Override
    public void dej() throws KolekceException {
        if (seznam.dejAkt()) {
            System.out.println(seznam.dejAktualni());
        } else {
            System.out.println("bohuzel neni nastaven aktualni prvek");
        }
    }

    @Override
    public void edit() throws KolekceException {
        if (seznam.getSize() == 0) {
            System.out.println("nelze editovat prvek v prazdnem seznamu");
        } else {
            if (seznam.dejAkt()) {

                seznam.dejAktualni().edituj();

            } else {
                System.out.println("nemuzeš editovat, jelikoz nebyl zvolen aktualni prvek");
            }
        }
    }

    @Override
    public void vyjmi() throws KolekceException {
        if (seznam.dejAkt() == false) {
            System.out.println("nelze  vyjimat jelikoz neni vybran aktualni prvek");
        } else {
            if (seznam.getSize() == 0) {
                System.out.println("nelze vyjimat prvek, jelikoz seznam je prazdny");
            } else {
                System.out.println("byl vyjmut prvek " + seznam.odeberAktualni());
            }
        }
    }

    @Override
    public void prvni() throws KolekceException {
        if (seznam.getSize() == 0) {
            System.out.println("nelze nastavit prvni prvek v prazdnem seznamu");
        } else {
            seznam.nastavPrvni();
            System.out.println("ukazatel nastaven na " + seznam.dejAktualni());
        }
    }

    @Override
    public void dalsi() throws KolekceException {
        if (seznam.dejAkt()) {
            if (seznam.getSize() < 2) {
                System.out.println("nelze nastavit dalsi prvek v takto malem seznamu");
            } else {
                seznam.dalsi();
                System.out.println("ukazatel nastaven na " + seznam.dejAktualni());
            }
        }
        else
        {
            System.out.println("nelze dat dalsi kdyz neni nastaven a");
        }
    }

    @Override
    public void posledni() throws KolekceException {
        if (seznam.getSize() == 0) {
            System.out.println("nelze nastavit posledni prvek v prazdnem seznamu");
        } else {
            seznam.nastavPosledni();
            System.out.println("ukazatel nastaven na " + seznam.dejAktualni());
        }
    }

    @Override
    public void pocet() {
        System.out.println("pocet prvku v seznamu je " + seznam.getSize());
    }

    @Override
    public void obnov() {
        binar.obnov();
    }

    @Override
    public void zalohuj() {
        binar.uloz();
    }

    @Override
    public void vypis() {
        if (seznam.getSize() == 0) {
            System.out.println("seznam je prazdny");
        } else {
            seznam.printList();
        }
    }

    @Override
    public void nactiText() throws KolekceException {
        if (textSoubor.VyctiText()) {
            System.out.println("seznam uspesne ulozen");
        } else {
            System.out.println("chyba pri nacteni");
        }
    }

    @Override
    public void ulozText() throws KolekceException {
        if (seznam.getSize() == 0) {
            System.out.println("je zbytecne ukladat prazdny seznam");
        } else {
            if (textSoubor.ZapisText()) {
                System.out.println("seznam uspesne ulozen");
            } else {
                System.out.println("chyba pri zapisu");
            }

        }
    }

    @Override
    public void generuj() {
        Generator g = new Generator();
        g.rand();
    }

    @Override
    public void zrus() {
        if (seznam.getSize() == 0) {
            System.out.println("seznam je jiz prazdny");
        } else {
            seznam.zrus();
            System.out.println("seznam byl vyprazdnen");
        }
    }

}
