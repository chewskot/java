/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cz.upce.fei.boop.pujcovna.generator;

import cz.upce.fei.boop.pujcovna.data.Lod;
import cz.upce.fei.boop.pujcovna.data.Lodicka;
import cz.upce.fei.boop.pujcovna.data.Rybarska;
import cz.upce.fei.boop.pujcovna.data.Yachta;
import java.util.Random;
import cz.upce.fei.boop.pujcovna.command.Commands;
import cz.upce.fei.boop.pujcovna.data.TypyLodi;

/**
 *
 * @author mojan
 */
public class Generator {

    public void rand() {
        Random rand = new Random();
        String[] nazvyLodi = {"Seawolf", "Aurora", "Clipper", "Maelstrom",
            "Navigator", "Oceanus", "Whirlpool", "Barracuda", "Dolphin",
            "Harmony", "Marina", "Serenity", "Wave Rider", "Atlantis",
            "Meridian", "Triton", "Sea Breeze", "Majestic", "Coral Reef",
            "Aquarius", "Calypso", "Bluewater", "Journey", "Odyssey",
            "Surf Rider", "Windward", "Riptide", "Starfish", "Bayliner",
            "Catalina", "Hatteras", "Islander", "Lagoon", "Mako", "Nautilus",
            "Outrider", "Pathfinder", "Reef Runner", "Sailfish", "Trawler",
            "Voyager", "Waverunner"};

        int randomNumber = rand.nextInt((20 - 5) + 1) + 5;
        for (int i = 0; i < randomNumber; i++) {
            int randNum = rand.nextInt(3);
            switch (randNum) {
                case 0 -> {
                    Lodicka l = new Lodicka(nazvyLodi[rand.nextInt(39)], rand.nextInt(70)+1, rand.nextInt(20)+1, rand.nextInt(3)+1,TypyLodi.LODICKA);
                    Commands.addDataToSeznam(l);
                }
                case 1 -> {
                    Yachta y = new Yachta(nazvyLodi[rand.nextInt(39)], rand.nextInt(70)+1, rand.nextInt(15)+1, rand.nextInt(3)+1,TypyLodi.YACHTA);
                    Commands.addDataToSeznam(y);
                }
                default -> {
                    Rybarska r = new Rybarska(nazvyLodi[rand.nextInt(39)], rand.nextInt(70)+1, rand.nextInt(80)+1, rand.nextInt(6)+1,TypyLodi.RYBARSKA);
                    Commands.addDataToSeznam(r);
                }

            }

        }
        System.out.println("bylo pridano " + randomNumber + " nahodnych dat");

    }
}
