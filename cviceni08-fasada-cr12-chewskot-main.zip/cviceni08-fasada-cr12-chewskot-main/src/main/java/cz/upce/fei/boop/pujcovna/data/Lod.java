/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cz.upce.fei.boop.pujcovna.data;

import static cz.upce.fei.boop.pujcovna.command.Commands.seznam;
import java.io.Serializable;
import java.util.Scanner;

/**
 *
 * @author mojan
 */
public abstract class Lod implements Serializable {

    private TypyLodi typ;
    private int rychlost;
    private int pocetMist;
    private String jmeno;
    public static int citac = 0;
    public int id;
    private boolean chyba = false;

    protected abstract String additionalString();

    public Lod(String jmeno, int rychlost, int pocetMist, TypyLodi typ) {

        this.jmeno = jmeno;
        id = citac++;
        this.typ = typ;
        if (rychlost < 0) {
            System.out.println("neni mozne aby lod nemela rychlost");
        } else {
            this.rychlost = rychlost;

        }
        if (pocetMist < 0) {
            System.out.println("neni mozne aby lod nemela mista");
        } else {
            this.pocetMist = pocetMist;
        }
    }

    public Lod() {
        try {
            Scanner scan = new Scanner(System.in);
            id = citac++;
            System.out.println("zadej rychlost ");
            String k = scan.nextLine();
            if (Integer.parseInt(k) > 0) {
                this.rychlost = Integer.parseInt(k);
                System.out.println("zadej pocet mist");
                k = scan.nextLine();
                if (Integer.parseInt(k) > 0) {
                    this.pocetMist = Integer.parseInt(k);
                    System.out.println("zadej nazev ");
                    k = scan.nextLine();
                    this.jmeno = k;

                } else {
                    System.out.println("pocet mist nemuze byt mensi nez nula");
                }
            } else {
                System.out.println("chyba rychlost nemuze byt menší než nula");

            }

        } catch (Exception e) {
            chyba = true;
            System.out.println("nastala chyba v zadávání dat prosím opravte jí opetovným zadáním příkazu");
        }

    }

    public void setJmeno(String jmeno) {
        this.jmeno = jmeno;
    }

    public void setTyp(TypyLodi typ) {
        this.typ = typ;
    }

    public void setRychlost(int rychlost) {
        this.rychlost = rychlost;
    }

    public void setPocetMist(int pocetMist) {
        this.pocetMist = pocetMist;
    }

    public String getAbs() {
        return additionalString();
    }

    public String getJmeno() {
        return jmeno;
    }

    public int getRychlost() {
        return rychlost;
    }

    public int getPocetMist() {
        return pocetMist;
    }

    public boolean getChyba() {
        return chyba;
    }

    public TypyLodi getTyp() {
        return typ;
    }

    public int getId() {
        return id;
    }

    public void edituj() {
        Scanner sken = new Scanner(System.in);
        System.out.println("budeme editovat jmeno,rychlost,mista?");
        System.out.println(toString());
        String volba = sken.nextLine();
        switch (volba) {
            case "jmeno":
                System.out.println("zadej nove jmeno");
                this.jmeno = sken.nextLine();
                break;
            case "rychlost":
                try {
                    System.out.println("zadej rychlost ");
                    int k = Integer.parseInt(sken.nextLine());
                    if (k > 0) {
                        this.rychlost = k;
                    } else {
                        System.out.println("chyba rychlost nemuze byt zaporna");
                    }
                    
                } catch (Exception e) {
                    chyba = true;
                    System.out.println("nastala chyba v zadávání dat prosím opravte jí opetovným zadáním příkazu");
                }   break;
            case "mista":
                try {
                    System.out.println("zadej pocet mist ");
                    int k = Integer.parseInt(sken.nextLine());
                    if (k > 0) {
                        this.pocetMist = k;
                    } else {
                        System.out.println("chyba pocet mist nemuze byt zaporny");
                    }
                    
                } catch (Exception e) {
                    chyba = true;
                    System.out.println("nastala chyba v zadávání dat prosím opravte jí opetovným zadáním příkazu");
                }   break;
            default:
                break;
        }

    }

    @Override
    public String toString() {
        String format = "Lod{typ=%-15s rychlost=%-2d pocetMist=%-2d jmeno=%-12s id=%-2d ";
        return String.format(format, typ, rychlost, pocetMist, jmeno, id) + additionalString() + "}";
    }

}
