/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package cz.upce.fei.book.pujcovna.spravce;

import cz.upce.fei.boop.pujcovna.kolekce.KolekceException;
import cz.upce.fei.boop.pujcovna.kolekce.LinkSeznam;
import java.util.Scanner;
import cz.upce.fei.boop.pujcovna.data.Lod;
import cz.upce.fei.boop.pujcovna.data.Lodicka;
import cz.upce.fei.boop.pujcovna.data.Rybarska;
import cz.upce.fei.boop.pujcovna.data.Yachta;
import cz.upce.fei.boop.pujcovna.generator.Generator;
import cz.upce.fei.boop.pujcovna.perzistence.binar;
import cz.upce.fei.boop.pujcovna.perzistence.textSoubor;

/**
 *
 * @author mojan
 */
public interface fasadaIn{

    public void novy() throws KolekceException;

    public void najdi();

    public void odeber() throws KolekceException;

    public void dej() throws KolekceException;

    public void edit() throws KolekceException;

    public void vyjmi() throws KolekceException;

    public void prvni() throws KolekceException;

    public void dalsi() throws KolekceException;

    public void posledni() throws KolekceException;

    public void pocet();

    public void obnov();

    public void zalohuj();

    public void vypis();

    public void nactiText() throws KolekceException;

    public void ulozText() throws KolekceException;

    public void generuj();

    public void zrus();

}
