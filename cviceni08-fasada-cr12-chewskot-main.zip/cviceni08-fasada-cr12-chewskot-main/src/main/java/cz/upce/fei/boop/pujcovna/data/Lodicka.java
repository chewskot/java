package cz.upce.fei.boop.pujcovna.data;

import java.util.Scanner;

/**
 *
 * @author mojan
 */
public class Lodicka extends Lod {

    public void setPocetPlachet(int pocetPlachet) {
        this.pocetPlachet = pocetPlachet;
    }

    @Override
    protected String additionalString() {
        return " pocet plachet= " + getPocetPlachet();
    }

    private int pocetPlachet;

    public Lodicka(String jmeno, int rychlost, int pocetMist, int pocetPlachet, TypyLodi typ) {
        super(jmeno, rychlost, pocetMist, typ);
        if (pocetPlachet > 3) {
            System.out.println("neni mozne mit na lodicce vice nez tri plachty");

        } else if (pocetPlachet < 0) {
            System.out.println("lodicka nemuze byt bez plachet");
        } else {
            this.pocetPlachet = pocetPlachet;
        }

    }

    public Lodicka() {

        try {

            if(!super.getChyba())
            {
                Scanner scan = new Scanner(System.in);
            super.setTyp(TypyLodi.LODICKA);

            System.out.println("zadejte pocet plachet");
            int k =Integer.parseInt(scan.nextLine());
            
            if (k > 3) {
                System.out.println("neni mozne mit na lodicce vice nez tri plachty");

            } else if (k < 0) {
                System.out.println("lodicka nemuze byt bez plachet");
            } else {
                this.pocetPlachet = k;
                System.out.println("uspesne jsi vlozil lodicku");
            }
            }
            

        } catch (NumberFormatException e) {
            System.out.println("nastala chyba v zadávání dat prosím opravte jí opetovným zadáním příkazu");
        }
    }

    public int getPocetPlachet() {
        return pocetPlachet;
    }

}
