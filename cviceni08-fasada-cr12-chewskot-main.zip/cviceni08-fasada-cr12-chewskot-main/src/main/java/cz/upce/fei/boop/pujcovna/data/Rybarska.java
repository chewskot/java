package cz.upce.fei.boop.pujcovna.data;

import java.util.Scanner;

/**
 *
 * @author mojan
 */
public class Rybarska extends Lod {

    public int getPocetSiti() {
        return pocetSiti;
    }

    public void setPocetSiti(int pocetSiti) {
        this.pocetSiti = pocetSiti;
    }

    private int pocetSiti;

    @Override
    protected String additionalString() {
        return " pocet siti= " + getPocetSiti();
    }

    public Rybarska(String jmeno, int rychlost, int pocetMist, int pocetSiti, TypyLodi typ) {
        super(jmeno, rychlost, pocetMist, typ);
        if (pocetSiti > 6) {
            System.out.println("neni mozne mit na rybarske lodi vice nez sest siti");

        } else if (pocetSiti < 0) {
            System.out.println("rybarska lod nemuze mit zaporny pocet siti");
        } else {
            this.pocetSiti = pocetSiti;
        }

    }

    public Rybarska() {

        try {

            if (!super.getChyba()) {
                Scanner scan = new Scanner(System.in);
                super.setTyp(TypyLodi.RYBARSKA);

                System.out.println("zadejte pocet siti");
                int k = Integer.parseInt(scan.nextLine());

                if (k > 4) {
                    System.out.println("neni mozne mit na lodicce vice nez ctyri site");

                } else if (k < 0) {
                    System.out.println("rybarska lod nemuze byt bez siti");
                } else {
                    this.pocetSiti = k;
                    System.out.println("uspesne jsi vlozil rybarskou lod");
                }
            }

        } catch (NumberFormatException e) {
            System.out.println("nastala chyba v zadávání dat prosím opravte jí opetovným zadáním příkazu");
        }
    }

}
