package cz.upce.fei.boop.pujcovna.command;

import cz.upce.fei.book.pujcovna.spravce.fasada;
import cz.upce.fei.boop.pujcovna.kolekce.KolekceException;
import cz.upce.fei.boop.pujcovna.kolekce.LinkSeznam;
import java.util.Scanner;
import cz.upce.fei.boop.pujcovna.data.Lod;
import cz.upce.fei.boop.pujcovna.data.Lodicka;
import cz.upce.fei.boop.pujcovna.data.Rybarska;
import cz.upce.fei.boop.pujcovna.data.Yachta;
import cz.upce.fei.boop.pujcovna.generator.Generator;
import cz.upce.fei.boop.pujcovna.perzistence.binar;
import cz.upce.fei.boop.pujcovna.perzistence.textSoubor;

/**
 *
 * @author mojan
 */
public class Commands {

    
    public static LinkSeznam<Lod> seznam = new LinkSeznam<>();

    public static void addDataToSeznam(Lod data) {
        seznam.vlozPosledni(data);
    }

    public static void main(String[] args) throws KolekceException {
        
        com();
    }

    public static void com() throws KolekceException{
        fasada fas = new fasada();
        System.out.println("Vitej v programu pro spravu pujcovny lodi");
        String help = """
                 //      help, h     - výpis příkazů 
                 //      novy,no     - vytvoř novou instanci a vlož data za aktuální prvek
                 //      najdi,na,n  - najdi v seznamu data podle hodnoty nějakém atributu //podle id
                  //     odeber,od   - odeber data ze seznamu podle nějaké hodnoty atributu  //podle id
                 //      dej         - zobraz aktuální data v seznamu
                       edituj,edit - edituj aktuální data v seznamu
                 //      vyjmi       - vyjmi aktuální data ze seznamu
                 //      prvni,pr    - nastav jako aktuální první data v seznamu
                  //     dalsi,da    - přejdi na další data
                  //     posledni,po - přejdi na poslední data
                  //     pocet       - zobraz počet položek v seznamu
                  //    obnov       - obnov seznam data z binárního souboru
                  //     zalohuj     - zálohuj seznam dat do binárního souboru
                 //      vypis       - zobraz seznam dat
                 //    nactitext,nt- načti seznam data z textového souboru
                 //      uloztext,ut - ulož seznam data do textového souboru
                 //      generuj,g   - generuj náhodně data pro testování
                 //      zrus        - zruš všechny data v seznamu
                 //      exit        - ukončení programu
                      """;
        System.out.println(help);
        Scanner scan = new Scanner(System.in);
        String comm = "";
        while (!comm.equals("exit")) {

            comm = scan.nextLine();
            switch (comm) {
                case "h", "help" ->
                    System.out.println(help);
                case "novy", "no" -> {
                    fas.novy();
                }
                case "vypis" -> {
                    fas.vypis();    
                }
                case "g", "generuj" -> {
                    fas.generuj();
                }
                case "dej" -> {
                    fas.dej();
                }
                case "vyjmi" -> {
                    fas.vyjmi();
                }
                case "pocet" ->
                    fas.pocet();
                case "prvni", "pr" -> {
                    fas.prvni();
                }
                case "dalsi", "da" -> {
                    fas.dalsi();
                }

                case "posledni", "po" -> {
                    fas.posledni();
                }
                case "edituj", "edit" -> {
                   fas.edit();
                }
                case "odeber", "od" -> {
                    fas.odeber();
                }
                case "uloztext", "ut" -> {
                    fas.ulozText();
                }
                case "nactitext", "nt" -> {

                   fas.nactiText();

                }

                case "najdi", "na","n" -> {
                   fas.najdi();
                }
                case "zrus" -> {
                    fas.zrus();
                }
                case "zalohuj" -> {
                    fas.zalohuj();
                }
                case "obnov" -> {
                    fas.obnov();
                }
                default ->
                    System.out.println("tento prikaz nefunguje zkuste h nebo help pro funkcni prikazy");
            }

        }
        System.out.println("diky za pouzivani programu");
    }

}
