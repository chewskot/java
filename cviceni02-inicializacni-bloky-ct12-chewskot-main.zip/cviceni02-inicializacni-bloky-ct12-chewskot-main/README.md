 1. Otevřete projekt v NetBeans a přejmenujte projekt tak, že místo koncovky 
    Prijmeni vložíte svoje příjmení. Jenom přejmenovaný projekt bude hodnocen.
 2. V NetBeans z menu Window/Action Items nebo Ctrl-6 otevřte okno Action Items.
 3. V okně Action Items klikněte na řádky TODO a vykonejte požadované úkoly.
 4. Po splnění úkolů TODO odešlete projekt do repository (commit a push). 
 