 1. Otevřete projekt v NetBeans a přejmenujte projekt tak, že místo koncovky 
    Prijmeni vložíte svoje příjmení. 
    Jenom přejmenovaný projekt bude hodnocen.
 2. V NetBeans z menu Window/Action Items nebo Ctrl-6 otevřte okno Action Items.
 3. V okně Action Items klikněte na řádky TODO a vykonejte požadované úkoly.
 4. Z úlohy U01 Neměnná třída převezměte třídu Rozmer s testem z větve main.  
 4. Implementaci všech tříd kontrolujte pomocí jejich testů.
 5. Postupujte tak, že nejdříve všechny testy vypnete zakomentováním 
    a potom je postupně aktivujte a doplňujte jednotlivé metody a konstruktory.
 6. Poté co všechny testy projdou, zkontrolujte pokrytí tříd takto:
    - a. Znovu aktivujte test, ale celého projektu, příkazem Run/Test Project (Alt-F6).
    - b. V kontextovém menu na projektu zvolte příkaz Code Coverage/ Show report.
    - c. Zobrazí se výsledek pokrytí.
    - d. Když bude řádek Total obsahovat 100%, tak jsou všechny příkazy tříd pokryty testy.
 7. Po získání plného pokrytí odešlete projekt do repository (commit a push). 
 8. U obou dvou variant klonování, tj. mělce a hluboce, spuste metodu main 
    a porovnejte výpisy. Věnujte pozornost hodnotám hashcode u van, které 
    vypíše metoda super.toString() v metodě toString.
 9. Zjištěné poznatky vložte do zadání úlohy v Moodle.   
