
package cz.upce.fei.boop.clonebathroom;

/**
 *
 * @author karel@simerda.cz
 */
public class MojeException extends RuntimeException {


    /**
     * Constructs an instance of <code>NewException</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public MojeException(String msg) {
        super(msg);
    }
}
