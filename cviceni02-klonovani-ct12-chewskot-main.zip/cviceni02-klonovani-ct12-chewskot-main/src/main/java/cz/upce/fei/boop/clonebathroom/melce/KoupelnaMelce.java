package cz.upce.fei.boop.clonebathroom.melce;

import cz.upce.fei.boop.clonebathroom.Rozmer;
import cz.upce.fei.boop.clonebathroom.Vana;
import cz.upce.fei.boop.clonebathroom.hluboce.KoupelnaHluboce;

/**
 * TODO Upravte třídu KoupelnaMelce tak vyhověla testu a byla mělce klonovatelná
 * TODO Při upravách třídy dodržujte strukturu třídy podle editor-fold
 */
public class KoupelnaMelce implements Cloneable {

    private String nazev;
    private Rozmer rozmer;
    private Vana vana;
//<editor-fold defaultstate="collapsed" desc="instanční proměnný/atributy">

//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="konstruktory">
//</editor-fold>    
    public KoupelnaMelce(String nazev, Rozmer rozmer, Vana vana) {
        if (rozmer == null) {
            throw new NullPointerException("Nazev vany nesmi byt null.");
        }
        if (nazev == null) {
            throw new NullPointerException("Nazev vany nesmi byt null.");
        }
        this.nazev = nazev;
        this.rozmer = rozmer;
        this.vana = vana;

    }
    public KoupelnaMelce(String nazev, double delka, double sirka, double vyska, Vana vana) {
        if (vana == null) {
            throw new NullPointerException("Nazev vany nesmi byt null.");
        }
       
        this.nazev = nazev;
        this.rozmer = new Rozmer(delka, sirka, vyska);
        this.vana = vana;
    }
    @Override
    public KoupelnaMelce clone() throws CloneNotSupportedException {
        return (KoupelnaMelce) super.clone();
    }
//<editor-fold defaultstate="collapsed" desc="klonování">
//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="metoda toString">
//</editor-fold>    
//<editor-fold defaultstate="collapsed" desc="Metody get/set ">
//</editor-fold>

    public String getNazev() {
        return nazev;
    }

    public Rozmer getRozmer() {
        return rozmer;
    }

    public Vana getVana() {
        return vana;
    }
}
