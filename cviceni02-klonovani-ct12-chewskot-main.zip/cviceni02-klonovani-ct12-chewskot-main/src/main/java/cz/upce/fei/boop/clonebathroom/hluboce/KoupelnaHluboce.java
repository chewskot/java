package cz.upce.fei.boop.clonebathroom.hluboce;

import cz.upce.fei.boop.clonebathroom.Rozmer;
import cz.upce.fei.boop.clonebathroom.Vana;

/**
 * TODO Upravte třídu KoupelnaHluboce tak vyhověla testu a byla hluboce
 * klonovatelná TODO Při upravách třídy dodržujte strukturu třídy podle
 * editor-fold
 */
public class KoupelnaHluboce implements Cloneable {

//<editor-fold defaultstate="collapsed" desc="instanční proměnný/atributy">
    private String nazev;
    private Rozmer rozmer;
    private Vana vana;

    public KoupelnaHluboce(String nazev, Rozmer rozmer, Vana vana) {
        if (nazev == null) {
            throw new NullPointerException("Nazev vany nesmi byt null.");
        }
        if (rozmer == null) {
            throw new NullPointerException("Rozmer nemůže být null");
        }
        if (vana == null) {
            throw new NullPointerException("Nevystavila se výjimka NullPointerException z důvodu null ve parametru na vanu koupelny");
        }

        this.nazev = nazev;
        this.rozmer = rozmer;
        this.vana = vana;
    }

    public KoupelnaHluboce(String nazev, double delka, double sirka, double vyska, Vana vana) {
        if (vana == null) {
            throw new NullPointerException("Nazev vany nesmi byt null.");
        }
        this.nazev = nazev;
        this.rozmer = new Rozmer(delka, sirka, vyska);
        this.vana = vana;
    }

    public Vana getVana() {
        return vana;
    }

    public Rozmer getRozmer() {
        return rozmer;
    }

    @Override
    public KoupelnaHluboce clone() throws CloneNotSupportedException {
        KoupelnaHluboce clone = (KoupelnaHluboce) super.clone();
        clone.vana = this.vana.clone();
        clone.rozmer = new Rozmer(this.rozmer.getSirka(),
                this.rozmer.getVyska(), this.rozmer.getDelka());
        return clone;
    }

    @Override
    public String toString() {
        return "KoupelnaHluboce{"
                + "nazev='" + nazev + '\''
                + ", rozmer=" + rozmer
                + ", vana=" + vana
                + '}';
    }

    public String getNazev() {
        return nazev;
    }

//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="konstruktory">
//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="metoda klonovani">
//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="metoda toString">
//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="metody get">
//</editor-fold>
}
