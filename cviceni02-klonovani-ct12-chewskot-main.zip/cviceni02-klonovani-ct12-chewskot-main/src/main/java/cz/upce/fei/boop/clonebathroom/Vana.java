package cz.upce.fei.boop.clonebathroom;

import java.util.Objects;

/*
 * TODO Upravte třídu Vana, tak vyhověla testu a byla klonovatelná
 * TODO Při upravách třídy dodržujte strukturu třídy podle editor-fold
//<editor-fold defaultstate="collapsed" desc="Konstruktory">
 */
public class Vana implements Cloneable {

    public String getNazevVany() {
        return nazevVany;
    }

    public Rozmer getRozmer() {
        return rozmer;
    }

    private final String nazevVany;
    private final Rozmer rozmer;
//<editor-fold defaultstate="collapsed" desc="Instanční proměnný/atributy">

//</editor-fold>
//</editor-fold>
    public Vana(String nazevVany, double delka, double sirka, double vyska) {
        if (nazevVany == null) {
            throw new NullPointerException("Nazev vany nesmi byt null.");
        }
        this.nazevVany = nazevVany;
        this.rozmer = new Rozmer(delka, sirka, vyska);
    }

    public Vana(String nazevVany, Rozmer rozmer) {
        if (nazevVany == null) {
            throw new NullPointerException("Nazev vany nesmi byt null.");
        }
        if (rozmer == null) {
            throw new NullPointerException("Rozmer nemůže být null");
        }
        this.nazevVany = nazevVany;
        this.rozmer = rozmer;
    }

    @Override
    public Vana clone() {
        try {
            return (Vana) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new NullPointerException();
        }
    }
//<editor-fold defaultstate="collapsed" desc="toString">

    @Override
    public String toString() {
        return "Vana " + nazevVany + "{" + rozmer + ", reference=" + super.toString() + '}';
    }

//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="Metody get">
//</editor-fold>    
//<editor-fold defaultstate="collapsed" desc="Metody equals a hashCode ">
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Vana)) {
            return false;
        }
        Vana vana = (Vana) o;
        return Objects.equals(nazevVany, vana.nazevVany) && Objects.equals(rozmer, vana.rozmer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nazevVany, rozmer);
    }

//</editor-fold>
}
