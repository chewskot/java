#Postup prací     
 1. Otevřete projekt v NetBeans a přejmenujte projekt tak, že místo koncovky 
    Prijmeni vložíte svoje příjmení. 
    - Jenom přejmenovaný projekt bude hodnocen.
 2. V NetBeans z menu Window/Action Items nebo Ctrl-6 otevřte okno Action Items.
 3. Podle úkolů TODO a rozhraní Seznam (signatura a kontrakt) 
    implementujte třídu SpojovySeznam.
 4. Implementaci ověřujte testovací třídou SpojovySeznamTest
 5. Testovací třídu postupně doplňujte vlastními testy podle implementace třídy
    SpojovySeznam.
 6. Vývoj třídy SpojovySeznam ukončete až po dosažení 100% pokrytí testy. 
 7. Uložte projekt do repository (commit a push) ve větvi "main".