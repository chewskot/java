package cz.upce.fei.boop.kolekce;

import java.util.Iterator;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author karel@simerda.cz
 */
public class SpojovySeznamTest {

    /**
     * Testovací třída pro ověření implementace třídy SpojovySeznam
     */
    private static class TestClass {

        int a;

        public TestClass(int a) {
            this.a = a;
        }

        @Override
        public String toString() {
            return "T" + a;
        }

    }
    /**
     * *
     * Sada instancí testovací třídy pro ověření implementace třídy
     * SpojovySeznam
     */
    private final TestClass T1 = new TestClass(1);
    private final TestClass T2 = new TestClass(2);
    private final TestClass T3 = new TestClass(3);
    private final TestClass T4 = new TestClass(4);
    private final TestClass T5 = new TestClass(5);
    private final TestClass T6 = new TestClass(6);
    private final TestClass T7 = new TestClass(7);
    private final TestClass T8 = new TestClass(8);
    private final TestClass T9 = new TestClass(9);

    public SpojovySeznamTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

// TODO Každou veřejnou metodu třídy SpojovySeznam ověřte alespoň jedním testem  
// TODO Dosáhněte 100% pokrytí třídy SpojovySeznam tímto testem    
// Ukázka jednoduchého testu    
    @Test
    public void test_01_01_VlozPrvni() {
        try {
            LinkSeznam<TestClass> instance = new LinkSeznam<>();
            instance.vlozPrvni(T8);
            TestClass[] expected = {T8};
            TestClass[] result = {instance.dejPrvni()};//            
            assertEquals(expected, result);
        } catch (Exception ex) {
            fail();
        }
    }
// Ukázka testu s vícenásobnou kontrolou stavu testované instance

    @Test
    public void test_01_02_VlozPrvni() {
        try {
            LinkSeznam<TestClass> instance = new LinkSeznam<>();
            instance.vlozPrvni(T8);
            instance.vlozPrvni(T4);
            TestClass[] result = {instance.dejPrvni(), instance.dejPosledni()};
            TestClass[] expected = {T4, T8};
            assertArrayEquals(expected, result);
        } catch (Exception ex) {
            fail();
        }
    }

    // Ukázka testu s vyvoláním výjimky   
    @Test(expected = NullPointerException.class)
    public void test_01_04_VlozPrvni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(null);
        fail();
    }

    @Test
    public void test_02_01_JePrazdny() {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        assertEquals(true, instance.jePrazdny());
    }

    @Test
    public void test_02_02_Zrus() {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPosledni(T8);
        instance.vlozPosledni(T4);
        instance.zrus();
        assertEquals(true, instance.jePrazdny());
    }

    @Test
    public void test_02_03_Size() {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T8);
        instance.vlozPosledni(T4);
        assertEquals(2, instance.size());
    }

    @Test(expected = KolekceException.class)
    public void test_03_01_OdeberPrvniJedenZJednoho() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T8);
        instance.vlozPosledni(T4);
        instance.odeberAktualni();
    }

    @Test
    public void test_03_02_OdeberPrvniJedenZJednoho() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T8);
        instance.vlozPrvni(T3);
        instance.vlozPrvni(T4);
        instance.vlozPrvni(T5);
        instance.vlozPrvni(T6);
        instance.vlozPosledni(T4);
        instance.nastavPosledni();
        instance.odeberAktualni();
        assertEquals(5, instance.size());
    }

    @Test(expected = KolekceException.class)
    public void test_03_03_OdeberPrvniJedenZJednoho() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T8);
        instance.odeberAktualni();
    }

    @Test(expected = KolekceException.class)
    public void test_03_04_OdeberPrvniJedenZJednoho() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.odeberAktualni();
        fail();
    }

    @Test
    public void test_04_01_DejZaAktualnim() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T4);
        instance.vlozPrvni(T8);
        instance.nastavPrvni();
        assertEquals(T4, instance.dejZaAktualnim());
    }

    @Test
    public void test_05_01_DejAktualniPosledni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T4);
        instance.vlozPrvni(T8);
        instance.nastavPosledni();
        assertEquals(T4, instance.dejAktualni());
    }

    @Test
    public void test_06_01_VlozZaAktualniPrvni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T8);
        instance.nastavPrvni();
        instance.vlozZaAktualni(T4);
        TestClass result = instance.dejPrvni();
        assertEquals(T8, result);
    }

    @Test(expected = KolekceException.class)
    public void test_06_02_VlozZaAktualniPrvni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozZaAktualni(T8);
        fail();
    }

    @Test(expected = NullPointerException.class)
    public void test_06_03_VlozZaAktualniPrvni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozZaAktualni(null);
        fail();
    }

    @Test
    public void test_07_01_JeDalsi() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPosledni(T8);
        instance.vlozPrvni(T4);
        instance.nastavPrvni();
        assertEquals(true, instance.jeDalsi());
    }

    @Test(expected = KolekceException.class)
    public void test_07_02_Dalsi() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPosledni(T8);
        instance.vlozPrvni(T4);
        instance.dalsi();
        assertEquals(T8, instance.dejAktualni());
    }

    @Test
    public void test_08_01_OdeberPosledniJedenZJednoho() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T8);
        instance.nastavPrvni();
        instance.vlozZaAktualni(T4);
        instance.odeberPosledni();
        assertEquals(T8, instance.dejPosledni());
    }

//    @Test
//    public void test_08_02_OdeberPosledniJedenZJednoho() throws KolekceException {
//        LinkSeznam<TestClass> instance = new LinkSeznam<>();
//        instance.vlozPosledni(T8);
//        instance.odeberPosledni();
//    }
    @Test(expected = KolekceException.class)
    public void test_08_03_OdeberPosledniJedenZJednoho() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.odeberPosledni();
        fail();
    }

    @Test
    public void test_09_01_OdeberZaAktualnim() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T4);
        instance.vlozPrvni(T8);
        instance.vlozPrvni(T3);
        instance.nastavPrvni();
        TestClass result = instance.odeberZaAktualnim();
        assertEquals(T8, result);
    }

    @Test(expected = KolekceException.class)
    public void test_09_02_OdeberZaAktualnim() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.odeberZaAktualnim();
    }

    @Test
    public void test_10_01_Iterator() {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T4);
        Iterator<TestClass> iterator = instance.iterator();
        assertEquals(T4, iterator.next());
    }

    @Test
    public void test_10_02_Iterator() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPosledni(T8);
        instance.vlozPrvni(T4);
        Iterator<TestClass> iterator = instance.iterator();
        assertEquals(true, iterator.hasNext());
    }

    @Test
    public void test_10_03_Iterator() {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T4);
        instance.vlozPrvni(T3);
        Iterator<TestClass> iterator = instance.iterator();
        assertEquals(T3, iterator.next());
        assertEquals(T4, iterator.next());
    }

    @Test
    public void test_11_01_OdeberPrvniJedenZJednoho() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T8);
        instance.odeberPrvni();
    }

    @Test(expected = KolekceException.class)
    public void test_11_02_OdeberPrvniChyba() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.odeberPrvni();
        fail();
    }

    @Test
    public void test_12_01_NastavPosledni() {
        try {
            LinkSeznam<TestClass> instance = new LinkSeznam<>();
            instance.vlozPrvni(T8);
            instance.nastavPosledni();
            TestClass result = instance.dejAktualni();
            TestClass expected = T8;
            assertEquals(expected, result);
        } catch (KolekceException ex) {
            fail();
        }
    }

    @Test
    public void test_12_02_NastavPosledni() {
        try {
            LinkSeznam<TestClass> instance = new LinkSeznam<>();
            instance.vlozPosledni(T8);
            instance.nastavPosledni();
            TestClass result = instance.dejAktualni();
            TestClass expected = T8;
            assertEquals(expected, result);
        } catch (KolekceException ex) {
            fail();
        }
    }

    @Test(expected = KolekceException.class)
    public void test_12_03_NastavPosledni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.nastavPosledni();
        fail();
    }

    @Test
    public void test_13_01_NastavPrvni() {
        try {
            LinkSeznam<TestClass> instance = new LinkSeznam<>();
            instance.vlozPrvni(T8);
            instance.nastavPrvni();
            TestClass result = instance.dejAktualni();
            TestClass expected = T8;
            assertEquals(expected, result);
        } catch (KolekceException ex) {
            fail();
        }
    }

    @Test(expected = KolekceException.class)
    public void test_13_02_NastavPrvni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.nastavPrvni();
        fail();
    }

    @Test
    public void test_14_01_VlozPosledni() {
        try {
            LinkSeznam<TestClass> instance = new LinkSeznam<>();
            instance.vlozPrvni(T8);
            instance.vlozPosledni(T4);
            TestClass[] result = {instance.dejPosledni()};
            TestClass[] expected = {T4};
            assertArrayEquals(expected, result);
        } catch (Exception ex) {
            fail();
        }
    }

    @Test(expected = NullPointerException.class)
    public void test_14_02_VlozPosledni() {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(null);
        fail();
    }

    @Test
    public void test_15_01_DejPrvni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T8);
        assertEquals(T8, instance.dejPrvni());
    }

    @Test
    public void test_15_02_DejPrvni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T8);
        instance.vlozPosledni(T4);
        assertEquals(T4, instance.dejPosledni());
    }

    @Test
    public void test_15_03_DejPrvni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T8);
        instance.vlozPosledni(T4);
        assertEquals(T4, instance.dejPosledni());
    }

    @Test
    public void test_15_04_DejPrvni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T8);
        instance.vlozPrvni(T4);
        instance.vlozPrvni(T3);
        instance.vlozPrvni(T4);
        instance.vlozPrvni(T5);
        assertEquals(T5, instance.dejPrvni());

    }

    @Test(expected = KolekceException.class)
    public void test_15_05_DejPrvni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.dejPrvni();
        fail();
    }

    @Test(expected = KolekceException.class)
    public void test_15_06_DejPosledni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.dejPosledni();
        fail();
    }

    @Test(expected = KolekceException.class)
    public void test_15_07_DejAktualni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.dejAktualni();
        fail();
    }

    @Test(expected = KolekceException.class)
    public void test_15_08_DejZaAktualnim() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.dejZaAktualnim();
        fail();
    }

    @Test
    public void test_17_01_Dopln() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T1);
        instance.vlozPrvni(T2);
        instance.odeberPosledni();
        assertEquals(T2, instance.dejPosledni());

    }

    @Test(expected = KolekceException.class)
    public void test_17_03_Dopln() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T3);
        instance.vlozPrvni(T2);
        instance.vlozPrvni(T1);

        instance.odeberPosledni();
        assertEquals(T1, instance.dejAktualni());

    }

    @Test
    public void test_17_04_Dopln() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T1);
        instance.nastavPrvni();
        instance.vlozZaAktualni(T2);
        instance.vlozZaAktualni(T3);
        instance.odeberPosledni();
        assertEquals(T3, instance.dejPosledni());

    }

    @Test
    public void test_17_05_Dopln() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T1);
        instance.nastavPrvni();
        instance.vlozZaAktualni(T2);
        instance.vlozZaAktualni(T3);
        TestClass result = instance.dejPosledni();
        assertEquals(T2, result);

    }

    @Test(expected = KolekceException.class)
    public void test_17_06_Dopln() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPosledni(T1);
        assertEquals(T1, instance.dejAktualni());
    }

    @Test(expected = KolekceException.class)
    public void test_17_07_VlozZaAktualni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T1);
        instance.vlozZaAktualni(T2);
        fail();
    }

    @Test(expected = KolekceException.class)
    public void test_17_08_OdeberPrvni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T1);
        instance.vlozPosledni(T2);
        instance.nastavPosledni();
        instance.odeberPosledni();
        instance.dejAktualni();

    }

    @Test(expected = KolekceException.class)
    public void test_17_09_OdeberPosledni() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPosledni(T1);
        instance.odeberPosledni();
        instance.dejPrvni();
    }

    @Test
    public void test_17_10_OdeberAktualni() {
        try {
            LinkSeznam<TestClass> instance = new LinkSeznam<>();
            instance.vlozPosledni(T1);
            instance.nastavPosledni();
            TestClass expected = T1;
            TestClass result = instance.odeberAktualni();
            assertEquals(expected, result);
        } catch (Exception ex) {
            fail();
        }
    }
    @Test
    public void test_17_11_Dopln() throws KolekceException {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T1);
        instance.nastavPrvni();
        instance.vlozZaAktualni(T2);
        TestClass result = instance.dejPosledni();
        assertEquals(T2, result);

    }

    @Test
    public void test16_01_dopln01() {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T8);
        assertEquals(false, instance.jeDalsi());

    }

    @Test(expected = KolekceException.class)
    public void test16_02_dopln02() throws KolekceException {

        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        instance.vlozPrvni(T8);
        instance.odeberAktualni();

    }

    @Test(timeout = 200L)
    public void test_Size10() {
        LinkSeznam<TestClass> instance = new LinkSeznam<>();
        for (int i = 0; i < 1000000; i++) {
            instance.vlozPrvni(T8);
        }
        int p = instance.size();
    }

}
