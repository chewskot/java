package cz.upce.fei.boop.kolekce;

/**

 * @author karel@simerda.cz
 */
public class KolekceException extends Exception {

    public KolekceException() {
    }

}
