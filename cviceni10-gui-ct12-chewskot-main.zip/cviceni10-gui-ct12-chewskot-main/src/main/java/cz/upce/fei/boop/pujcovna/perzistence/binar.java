/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cz.upce.fei.boop.pujcovna.perzistence;

import static cz.upce.fei.boop.pujcovna.spravce.Spravce.seznam;
import cz.upce.fei.boop.pujcovna.data.Lod;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Iterator;

/**
 *
 * @author mojan
 */
public  class binar {

    public static String uloz() {
        try {
            try ( FileOutputStream fos = new FileOutputStream("data.bin");  ObjectOutputStream oos = new ObjectOutputStream(fos)) {
                oos.writeInt(seznam.getSize());
                Iterator<Lod> it = seznam.iterator();
                while (it.hasNext()) {
                    oos.writeObject(it.next());
                }
            }
            return "Data written to file: data.bin";
        } catch (IOException e) {
            return "Nastala chyba";
        }
    }

    public static String obnov() {
        try {
            FileInputStream fis = new FileInputStream("data.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            int pocetPrvku = ois.readInt();
           // System.out.println("Number of elements: " + pocetPrvku);
            for (int i = 0; i < pocetPrvku; i++) {
                seznam.vlozPosledni((Lod) ois.readObject());
            }
            ois.close();
            fis.close();
            return "Pocet prvku je " + pocetPrvku;
        } catch (IOException | ClassNotFoundException e) {
            return "Nastala chyba";

        }
    }
}
