/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cz.upce.fei.boop.pujcovna.spravce;

import cz.upce.fei.boop.pujcovna.data.Lod;
import cz.upce.fei.boop.pujcovna.generator.Generator;
import cz.upce.fei.boop.pujcovna.kolekce.KolekceException;
import cz.upce.fei.boop.pujcovna.kolekce.LinkSeznam;
import cz.upce.fei.boop.pujcovna.perzistence.binar;
import cz.upce.fei.boop.pujcovna.perzistence.textSoubor;
import java.util.Iterator;
import java.util.Scanner;
import java.util.function.Consumer;
import java.util.function.Supplier;
import javafx.scene.control.Alert;

/**
 *
 * @author mojan
 */
public class Spravce implements Ispravce {

    public Spravce() {
    }

    public static Spravce vytvorComm(
            Consumer<String> errorLog,
            Supplier<LinkSeznam<Lod>> supplier) {
        Spravce commandy = new Spravce(errorLog);
        commandy.vytvorSeznam(supplier);
        return commandy;
    }

    Scanner scan = new Scanner(System.in);
    public static LinkSeznam<Lod> seznam = new LinkSeznam<>();
    private Consumer<String> errorLog;

    public static void addDataToSeznam(Lod data) {
        seznam.vlozPosledni(data);
    }

    public Spravce(Consumer<String> errorLog) {
        this.errorLog = errorLog;
    }

    @Override
    public void vytvorSeznam(Supplier<LinkSeznam<Lod>> supplier) {
        seznam = supplier.get();
    }

    @Override
    public void novy(Lod lod) throws KolekceException {
        seznam.vlozPosledni(lod);

    }

    @Override
    public Lod najdi(int id) {
        if (seznam.getSize() == 0) {
            showError("Nelze vyhledavat v prazdnem seznamu");
        } else {
            
            Lod k = seznam.Najdi(seznam, id);
            if (k == null) {
                showError("zadna polozka s timto id neexistuje");
            } else {
                return k;
            }

        }
        return null;

    }
    public boolean dejAkt()
    {
        return seznam.dejAkt();
    }

    @Override
    public String odeber() throws KolekceException {
        if (seznam.getSize() == 0) {
            return "nelze odebrat prvek, jelikož seznam je prazdny";
        } else {
            if (seznam.dejAkt()) {

                return seznam.odeberAktualni() + "byl uspesne odebran";
            } else {
                return "neni nastaven aktualni prvek";
            }
        }

    }

    @Override
    public Lod dej() throws KolekceException {
        if (seznam.dejAkt()) {
            return seznam.dejAktualni();
        } else {
            showError("Neni nastaven aktualni prvek");
            return null;
        }

    }

    @Override
    public String edit() throws KolekceException {
        if (seznam.getSize() == 0) {
            System.out.println("nelze editovat prvek v prazdnem seznamu");
        } else {
            if (seznam.dejAkt()) {

                seznam.dejAktualni().edituj();

            } else {
                System.out.println("nemuzeš editovat, jelikoz nebyl zvolen aktualni prvek");
            }
        }
        return null;
    }

    @Override
    public String vyjmi() throws KolekceException {
        if (seznam.dejAkt() == false) {
            return "nelze  vyjimat jelikoz neni vybran aktualni prvek";
        } else {
            if (seznam.getSize() == 0) {
                return "nelze vyjimat prvek, jelikoz seznam je prazdny";
            } else {
                
                return "byl vyjmut prvek " + seznam.odeberAktualni();
            }
        }

    }

    @Override
    public void vypis(Consumer<Lod> writer) {
        stream().forEach(writer);
    }

    @Override
    public String prvni() throws KolekceException {
        if (seznam.getSize() == 0) {
            return "nelze nastavit prvni prvek v prazdnem seznamu";
        } else {
            seznam.nastavPrvni();
            return "ukazatel nastaven na " + seznam.dejAktualni();
        }

    }

    @Override
    public String dalsi() throws KolekceException {
        if (seznam.dejAkt()) {
            if (seznam.getSize() < 2) {
                return "nelze nastavit dalsi prvek v takto malem seznamu";
            } else {
                seznam.dalsi();
                return "ukazatel nastaven na " + seznam.dejAktualni();
            }
        } else {
            return "nelze dat dalsi kdyz neni nastaven a";
        }

    }

    @Override
    public String posledni() throws KolekceException {
        if (seznam.getSize() == 0) {
            return "nelze nastavit posledni prvek v prazdnem seznamu";
        } else {
            seznam.nastavPosledni();
            return "ukazatel nastaven na " + seznam.dejAktualni();
        }

    }

    @Override
    public int pocet() {
        return seznam.getSize();

    }

    @Override
    public String obnov() {

        return binar.obnov();
    }

    @Override
    public String zalohuj() {
        return binar.uloz();

    }

    @Override
    public void nactiText() throws KolekceException {
        if (textSoubor.VyctiText()) {
            
        } 

    }

    @Override
    public String ulozText() throws KolekceException {
        if (seznam.getSize() == 0) {
            return "je zbytecne ukladat prazdny seznam";
        } else {
            if (textSoubor.ZapisText()) {
                return "seznam uspesne ulozen";
            } else {
                return "chyba pri zapisu";
            }

        }

    }

    @Override
    public void generuj() {
        try {
            Generator g = new Generator();
            g.rand(seznam);
        } catch (Exception e) {
            showError("Chyba pri generovani");
        }

    }
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(message);
        alert.showAndWait();
    }

    @Override
    public String zrus() {
        if (seznam.getSize() == 0) {
            return "seznam je jiz prazdny";
        } else {
            seznam.zrus();
            return "seznam byl vyprazdnen";
        }

    }

    @Override
    public Iterator<Lod> iterator() {
        return seznam.iterator();
    }

    public void predchozi() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
