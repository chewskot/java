package cz.upce.fei.boop.pujcovna.gui;

import cz.upce.fei.boop.pujcovna.data.Lod;
import cz.upce.fei.boop.pujcovna.data.TypyLodi;
import cz.upce.fei.boop.pujcovna.kolekce.KolekceException;
import cz.upce.fei.boop.pujcovna.kolekce.LinkSeznam;
import cz.upce.fei.boop.pujcovna.spravce.Spravce;
import java.io.IOException;
import java.util.Arrays;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.geometry.Insets;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class GUI extends Application {

    private static final int SCENE_WIDTH = 820;
    private static final int SCENE_HEIGHT = 700;
    //public static LinkSeznam<Lod> linkSeznam = new LinkSeznam();

    public static ComboBox<TypyLodi> filtrChoice;
    public Spravce sprav;
    private ListView<Lod> listView = new ListView<>(FXCollections.observableArrayList());

    @Override

    public void start(Stage primaryStage) {

        sprav = sprav.vytvorComm(er -> showError(er), LinkSeznam<Lod>::new);
        sprav.vytvorSeznam(LinkSeznam::new);
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));

        // Create a ListView on the left side
        listView.setPrefWidth(SCENE_WIDTH * 0.8); // Set the preferred width to 80% of the scene width
        root.setLeft(listView);

        // Create an HBox at the bottom
        HBox hbox = new HBox();
        hbox.setPadding(new Insets(10));
        hbox.setSpacing(10);

        Button generujBtn = new Button("Generuj");
        Button ulozBtn = new Button("Uloz");
        Button nactiBtn = new Button("Nacti");
        Label novyLabel = new Label("Novy:");

        Button pridejBtn = new Button("Pridej");
        Label filtrLabel = new Label("Filtr:");

        filtrChoice = new ComboBox<>();
        filtrChoice.getItems().addAll(Arrays.asList(TypyLodi.values()));
        filtrovani(filtrChoice);

        Button smazFiltrBtn = new Button("Smaz filtr");
        smazFiltrBtn.setOnAction(e -> {
            filtrChoice.getItems().clear();
            filtrChoice.getItems().addAll(Arrays.asList(TypyLodi.values()));
            vypisObr();
        });

        Button najdiBtn = new Button("Najdi");
        Button zalohujBtn = new Button("Zalohuj");
        Button obnovBtn = new Button("Obnov");
        Button zrusBtn = new Button("Zrus");

        hbox.getChildren().addAll(generujBtn, ulozBtn, nactiBtn, novyLabel, pridejBtn, filtrLabel, filtrChoice, smazFiltrBtn, najdiBtn, zalohujBtn, obnovBtn, zrusBtn);

        root.setBottom(hbox);

        // Create a VBox on the right side
        VBox vbox2 = new VBox();
        vbox2.setPadding(new Insets(10));
        vbox2.setSpacing(10);

        Label prochazeniLabel = new Label("Prochazeni");
        Button prvniBtn = new Button("Prvni");
        Button dalsiBtn = new Button("Dalsi");
        Button predchoziBtn = new Button("Predchozi");
        Button posledniBtn = new Button("Posledni");
        Label prikazyLabel = new Label("Prikazy");
        Button editujBtn = new Button("Edituj");
        Button vyjmiBtn = new Button("Vyjmi");

        vbox2.getChildren().addAll(prochazeniLabel, prvniBtn, dalsiBtn, predchoziBtn, posledniBtn, prikazyLabel, editujBtn, vyjmiBtn);

        root.setRight(vbox2);

        generujBtn.setOnAction(event -> {
            sprav.generuj();
            vypisObr();
        });
        ulozBtn.setOnAction(event
                -> {
            try {
                sprav.ulozText();

            } catch (KolekceException ex) {
                showError("Nastala chyba pri ukladani");
            }
        });
        nactiBtn.setOnAction(e -> {
            try {
                sprav.nactiText();
            } catch (KolekceException ex) {
                showError("Nastala chyba pri nacitani");
            }
            vypisObr();
        });
        najdiBtn.setOnAction(e -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Hledani lodi");
            dialog.setHeaderText("Zadejte ID lodi");
            Optional<String> idDialog = dialog.showAndWait();
            if (idDialog.isPresent()) {
                try {
                    int id = Integer.parseInt(dialog.getEditor().getText());
                    if (sprav.najdi(id) != null) {
                        listView.getSelectionModel().select(sprav.najdi(id));
                    } else {
                        showError("ID v seznamu neni");
                    }
                } catch (NumberFormatException ex) {
                    showError("Spatne zadane ID");
                }

            }
        });
        zalohujBtn.setOnAction(event
                -> {
            sprav.zalohuj();
        });
        obnovBtn.setOnAction(event
                -> {
            sprav.obnov();
            vypisObr();
        });
        zrusBtn.setOnAction(event -> {
            sprav.zrus();
            listView.getItems().clear();
        });
        pridejBtn.setOnAction(event
                -> {
            DialogTvorba dialog = DialogTvorba.zapnoutDialog();
            Lod lod = dialog.returnLod();
            if (lod != null) {
                try {
                    sprav.novy(lod);
                    listView.getItems().add(lod);
                } catch (KolekceException ex) {
                    showError("Nastala chyba pri pridavani");
                }

            }

        });
        prvniBtn.setOnAction(event -> {
            try {
                sprav.prvni();
                listView.getSelectionModel().select(sprav.dej());
            } catch (KolekceException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }

        });
        dalsiBtn.setOnAction(event -> {
            try {
                sprav.dalsi();
                listView.getSelectionModel().select(sprav.dej());
            } catch (KolekceException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }

        });
        predchoziBtn.setOnAction(event -> {
            try {
                if (sprav.dej() == null) {

                } else {
                    if (sprav.pocet() == 0) {
                        showError("Prazdny seznam");
                    } else {
                        int i = listView.getSelectionModel().getSelectedIndex();
                        listView.getSelectionModel().selectPrevious();
                        if (i - 1 < 0) {
                            showError("Jsi na zacatku seznamu");
                            listView.getSelectionModel().select(i);

                        } else {

                            try {
                                sprav.prvni();
                                while (sprav.dej() != listView.getSelectionModel().getSelectedItem()) {
                                    sprav.dalsi();
                                }
                            } catch (KolekceException ex) {
                                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                }
            } catch (KolekceException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        posledniBtn.setOnAction(e -> {
            try {
                sprav.posledni();
                listView.getSelectionModel().select(sprav.dej());
            } catch (KolekceException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }

        });
        editujBtn.setOnAction(event -> {

            edituj();
            listView.getItems().clear();
            vypisObr();
        });
        vyjmiBtn.setOnAction(e -> {
            try {
                if (sprav.dej() != null) {
                    sprav.vyjmi();
                    listView.getItems().remove(listView.getSelectionModel().getSelectedItem());
                    listView.getItems().clear();
                    vypisObr();
                }
            } catch (KolekceException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        Scene scene = new Scene(root, SCENE_WIDTH, SCENE_HEIGHT);
        primaryStage.setScene(scene);
        primaryStage.setTitle("JavaFX App");
        primaryStage.show();
    }

    private void filtrovani(ComboBox<TypyLodi> comboBox) {
        comboBox.valueProperty().addListener(e -> {
            TypyLodi typ = comboBox.getValue();
            listView.getItems().clear();
            sprav.vypis(lod -> {
                if (lod.getTyp() == typ) {
                    listView.getItems().add(lod);
                }
            });
        });
    }

    private void vypisObr() {
        listView.getItems().clear();
        sprav.vypis(lod -> listView.getItems().add(lod));
    }

    private void edituj() {

        try {
            DialogEdit dialog = DialogEdit.zapnoutEditDialog(listView.getSelectionModel().getSelectedItem());
            Lod editovanaLod = dialog.editedLod();
            //listView.getSelectionModel().getSelectedItem().setJmeno(editovanaLod.getJmeno());
            listView.getSelectionModel().getSelectedItem().setJmeno(editovanaLod.getJmeno());
            listView.getSelectionModel().getSelectedItem().setRychlost((int) editovanaLod.getRychlost());
            listView.getSelectionModel().getSelectedItem().setTyp(editovanaLod.getTyp());
            listView.getSelectionModel().getSelectedItem().setPocetMist((int) editovanaLod.getPocetMist());

            listView.getItems().clear();
            vypisObr();

        } catch (Exception e) {
            showError("neni vybran aktualni prvek");
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
