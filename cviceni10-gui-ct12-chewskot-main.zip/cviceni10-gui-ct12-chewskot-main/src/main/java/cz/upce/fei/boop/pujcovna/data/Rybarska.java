package cz.upce.fei.boop.pujcovna.data;

import java.util.Scanner;

/**
 *
 * @author mojan
 */
public class Rybarska extends Lod {

    @Override
    public int getPocetPlachet() {
        return pocetSiti;
    }

    @Override
    public void setPocetPlachet(int pocetSiti) {
        this.pocetSiti = pocetSiti;
    }

    private int pocetSiti;

    @Override
    protected String additionalString() {
        return " pocet plachet= " + getPocetPlachet();
    }

    public Rybarska(String jmeno, int rychlost, int pocetMist, int pocetSiti, TypyLodi typ) {
        super(jmeno, rychlost, pocetMist, typ);
        

    }

    

}
