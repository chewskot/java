/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cz.upce.fei.boop.pujcovna.gui;

import cz.upce.fei.boop.pujcovna.data.Yachta;
import cz.upce.fei.boop.pujcovna.data.Rybarska;
import cz.upce.fei.boop.pujcovna.data.Lodicka;
import cz.upce.fei.boop.pujcovna.data.TypyLodi;

import cz.upce.fei.boop.pujcovna.data.Lod;
import java.util.Arrays;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class DialogTvorba {

    private final Dialog<Lod> dialog;
    private GridPane gridpane;
    private ComboBox<TypyLodi> cmBoxTypLodi;
    private final TextField txtNazev = new TextField("");
    private final TextField txtRychlost = new TextField("");
    private final TextField txtPocetMist = new TextField("");
    private final TextField txtArg = new TextField("");
    private Label argLabel = new Label("Pocet plachet");
    private Lod lod;

    public DialogTvorba() {
        dialog = new Dialog<>();
        dialog.setTitle("Pridani nove lodi");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        vytvorGridPane();
    }

    private void vytvorGridPane() {
        gridpane = new GridPane();
        gridpane.setMinHeight(100);
        gridpane.setVgap(5);
        gridpane.setHgap(5);
        gridpane.setPadding(new Insets(10, 20, 10, 10));

        nastavGridpane();

        getLod();

        dialog.getDialogPane().setContent(gridpane);
        dialog.showAndWait();
    }

    public static DialogTvorba zapnoutDialog() {
        return new DialogTvorba();
    }

    private void nastavGridpane() {
        cmBoxTypLodi = new ComboBox<>();
        gridpane.add(new Label("Typ lodi: "), 0, 0);
        gridpane.add(cmBoxTypLodi, 1, 0);
        cmBoxTypLodi.getItems().addAll(Arrays.asList(TypyLodi.values()));

        gridpane.add(new Label("Název lodi:"), 0, 1);
        gridpane.add(txtNazev, 1, 1);
        gridpane.add(new Label("Rychlost lodi:"), 0, 2);
        gridpane.add(txtRychlost, 1, 2);
        gridpane.add(new Label("Váha lodi:"), 0, 3);
        gridpane.add(txtPocetMist, 1, 3);
        gridpane.add(argLabel, 0, 4);
        gridpane.add(txtArg, 1, 4);
    }

    Lod returnLod() {
        return lod;
    }

    private void getLod() {
        dialog.setResultConverter(e -> {
            if (e == ButtonType.OK) {
                String nazev = txtNazev.getText();
                int rychlost = 0;
                int pocetMist = 0;
                int argu = 0;
                try {
                    rychlost = Integer.parseInt(txtRychlost.getText());
                    pocetMist = Integer.parseInt(txtPocetMist.getText());
                    argu = Integer.parseInt(txtArg.getText());
                } catch (NumberFormatException ex) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Neplatný vstup");
                    alert.setContentText(ex.getMessage());
                    alert.showAndWait();
                    return null;
                }
                TypyLodi typLodi = cmBoxTypLodi.getSelectionModel().getSelectedItem();
                try {
                    switch (typLodi) {
                    case LODICKA:
                        argLabel.setText("Pocet plachet");
                        lod = new Lodicka(nazev, rychlost, pocetMist, argu, TypyLodi.LODICKA);
                        break;
                    case RYBARSKA:
                        lod = new Rybarska(nazev, rychlost, pocetMist,argu, TypyLodi.RYBARSKA);
                        break;
                    case YACHTA:
                        lod = new Yachta(nazev, rychlost, pocetMist, argu, TypyLodi.YACHTA);
                        break;
                    

                }
                } catch (Exception l) {
       
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText("Je potreba vybrat typ lodi");
                        alert.showAndWait();
                }
                return lod;
            }
            return null;
        });
    }

}
