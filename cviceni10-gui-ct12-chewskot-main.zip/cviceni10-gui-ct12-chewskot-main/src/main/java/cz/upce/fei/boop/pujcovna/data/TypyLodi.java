package cz.upce.fei.boop.pujcovna.data;

/**
 *
 * @author mojan
 */
public enum TypyLodi {
    LODICKA("lodicky"),
    RYBARSKA("rybarske lodi"),
    YACHTA("yachty");

    private final String nazev;

    private TypyLodi(String nazev) {
        this.nazev = nazev;
    }

    public String nazev() {
        return nazev;
    }

    @Override
    public String toString() {
        return nazev;
    }

}

