package cz.upce.fei.boop.pujcovna.data;

import java.util.Scanner;

/**
 *
 * @author mojan
 */
public class Lodicka extends Lod {

    public void setPocetPlachet(int pocetPlachet) {
        this.pocetPlachet = pocetPlachet;
    }

    @Override
    protected String additionalString() {
        return " pocet plachet= " + getPocetPlachet();
    }

    private int pocetPlachet;

    public Lodicka(String jmeno, int rychlost, int pocetMist, int pocetPlachet, TypyLodi typ) {
        super(jmeno, rychlost, pocetMist, typ);
       if (pocetPlachet < 0) {
            System.out.println("lodicka nemuze byt bez plachet");
            super.setChyba(true);
        } else {
            this.pocetPlachet = pocetPlachet;
        }

    }

    public Lodicka() {

        

   
    }

    public int getPocetPlachet() {
        return pocetPlachet;
    }

}
