package cz.upce.fei.boop.pujcovna.kolekce;

/**

 * @author karel@simerda.cz
 */
public class KolekceException extends Exception {

    public KolekceException() {
    }

}
