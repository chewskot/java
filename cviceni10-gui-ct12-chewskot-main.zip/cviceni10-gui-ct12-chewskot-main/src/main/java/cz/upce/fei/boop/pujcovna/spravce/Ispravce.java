/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package cz.upce.fei.boop.pujcovna.spravce;

import cz.upce.fei.boop.pujcovna.kolekce.KolekceException;
import cz.upce.fei.boop.pujcovna.data.Lod;
import cz.upce.fei.boop.pujcovna.kolekce.LinkSeznam;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 *
 * @author mojan
 */
public interface Ispravce extends Iterable<Lod>{

    public void novy(Lod lod) throws KolekceException;

    public Lod najdi(int id);

    default Stream<Lod> stream() {
        return StreamSupport.stream(spliterator(), false);
    }

    public String odeber() throws KolekceException;
    void vytvorSeznam(Supplier<LinkSeznam<Lod>> supplier);

    public Lod dej() throws KolekceException;

    public String edit() throws KolekceException;

    public String vyjmi() throws KolekceException;

    public String prvni() throws KolekceException;

    public String dalsi() throws KolekceException;

    public String posledni() throws KolekceException;

    public int pocet();

    public String obnov();

    public String zalohuj();

    public void vypis(Consumer<Lod> writer);

    public void nactiText() throws KolekceException;

    public String ulozText() throws KolekceException;

    public void generuj();

    public String zrus();

}
