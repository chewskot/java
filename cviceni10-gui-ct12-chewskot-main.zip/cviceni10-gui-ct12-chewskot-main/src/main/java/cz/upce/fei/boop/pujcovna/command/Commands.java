package cz.upce.fei.boop.pujcovna.command;

import cz.upce.fei.boop.pujcovna.data.Lod;
import cz.upce.fei.boop.pujcovna.spravce.Spravce;
import cz.upce.fei.boop.pujcovna.kolekce.KolekceException;
import cz.upce.fei.boop.pujcovna.kolekce.LinkSeznam;

import java.util.Scanner;

/**
 *
 * @author mojan
 */
public class Commands {

    public static void main(String[] args) throws KolekceException {

        com();
    }

    public static void com() throws KolekceException {
        Spravce fas = new Spravce();
        System.out.println("Vitej v programu pro spravu pujcovny lodi");
        String help = """
                 //      help, h     - výpis příkazů 
                 //      novy,no     - vytvoř novou instanci a vlož data za aktuální prvek
                 //      najdi,na,n  - najdi v seznamu data podle hodnoty nějakém atributu //podle id
                  //     odeber,od   - odeber data ze seznamu podle nějaké hodnoty atributu  //podle id
                 //      dej         - zobraz aktuální data v seznamu
                       edituj,edit - edituj aktuální data v seznamu
                 //      vyjmi       - vyjmi aktuální data ze seznamu
                 //      prvni,pr    - nastav jako aktuální první data v seznamu
                  //     dalsi,da    - přejdi na další data
                  //     posledni,po - přejdi na poslední data
                  //     pocet       - zobraz počet položek v seznamu
                  //    obnov       - obnov seznam data z binárního souboru
                  //     zalohuj     - zálohuj seznam dat do binárního souboru
                 //      vypis       - zobraz seznam dat
                 //    nactitext,nt- načti seznam data z textového souboru
                 //      uloztext,ut - ulož seznam data do textového souboru
                 //      generuj,g   - generuj náhodně data pro testování
                 //      zrus        - zruš všechny data v seznamu
                 //      exit        - ukončení programu
                      """;
        System.out.println(help);
        Scanner scan = new Scanner(System.in);
        String comm = "";
        
        while (!comm.equals("exit")) {

            comm = scan.nextLine();
            switch (comm) {
                case "h", "help" ->
                    System.out.println(help);
                case "novy", "no" -> {
                    System.out.println("budeme vytvaret lodicku,yachtu nebo rybarskou lod?");
                    System.out.println("pro lodicku napiste l nebo lodicka");
                    System.out.println("pro yachtu napiste y nebo yachta");
                    System.out.println("pro rybarskou lod napiste r nebo rybarska");

                    String n = scan.nextLine();
                    //System.out.println(fas.novy(lod l = new Lod()));
                }
//                case "vypis" -> {
//
//                    String[] vypis = fas.vypis();
//                    for (int i = 0; i < vypis.length; i++) {
//                        System.out.println(vypis[i]);
//                    }
//                }
                case "g", "generuj" -> {
                //    System.out.println(fas.generuj());
                }
                case "dej" -> {
                    System.out.println(fas.dej());
                }
                case "vyjmi" -> {
                    System.out.println(fas.vyjmi());
                }
                case "pocet" ->
                    System.out.println(fas.pocet());
                case "prvni", "pr" -> {
                    System.out.println(fas.prvni());
                }
                case "dalsi", "da" -> {
                    System.out.println(fas.dalsi());
                }

                case "posledni", "po" -> {
                    System.out.println(fas.posledni());
                }
                case "edituj", "edit" -> {
                    fas.edit();
                }
                case "odeber", "od" -> {
                    System.out.println(fas.odeber());
                }
                case "uloztext", "ut" -> {
                    System.out.println(fas.ulozText());
                }
                case "nactitext", "nt" -> {

                   // System.out.println(fas.nactiText());

                }

                case "najdi", "na","n" -> { //potreba doupravit
                    //System.out.println(fas.najdi());
                }
                case "zrus" -> {
                    System.out.println(fas.zrus());
                }
                case "zalohuj" -> {
                    System.out.println(fas.zalohuj());
                }
                case "obnov" -> {
                    System.out.println(fas.obnov());
                }
                case "exit" -> {
                    System.out.println("");
                }
                default ->
                    System.out.println("tento prikaz nefunguje zkuste h nebo help pro funkcni prikazy");
            }

        }
        System.out.println("diky za pouzivani programu");
    }

}
