/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cz.upce.fei.boop.pujcovna.gui;

import cz.upce.fei.boop.pujcovna.data.Lod;
import cz.upce.fei.boop.pujcovna.data.TypyLodi;
import java.util.Arrays;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;



public class DialogEdit {

    private final Dialog<Lod> dialog;
    private final GridPane gridpane;
    //private ComboBox<TypyLodi> cmBoxTypLodi;
    private final TextField txtNazev = new TextField("");
    private final TextField txtRychlost = new TextField("");
    private final TextField txtPocetMist = new TextField("");
    private final TextField txtPlachty = new TextField("");
    private final Lod editedLod;

    public static DialogEdit zapnoutEditDialog(Lod lod) {
        return new DialogEdit(lod);
    }

    public DialogEdit(Lod lod) {
        editedLod = lod;
        dialog = new Dialog<>();
        dialog.setTitle("Uprava parametru");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        gridpane = new GridPane();
        gridpane.setMinHeight(100);
        gridpane.setHgap(12);
        gridpane.setVgap(12);
        gridpane.setPadding(new Insets(10, 20, 10, 10));

        nastavGridpane();

        dialog.getDialogPane().setContent(gridpane);
        dialog.showAndWait();
        editujLod();

    }

    Lod editedLod() {
        return editedLod;
    }

    private void nastavGridpane() {
        //cmBoxTypLodi = new ComboBox<>();
        //gridpane.add(new Label("Typ lodi: "), 0, 0);
       // gridpane.add(cmBoxTypLodi, 1, 0);
        //cmBoxTypLodi.getItems().addAll(Arrays.asList(TypyLodi.values()));
        gridpane.add(new Label("Název lodi:"), 0, 1);
        gridpane.add(txtNazev, 1, 1);
        txtNazev.setText(editedLod.getJmeno());
        gridpane.add(new Label("Rychlost lodi:"), 0, 2);
        gridpane.add(txtRychlost, 1, 2);
        txtRychlost.setText(Integer.toString((int) editedLod.getRychlost()));
        gridpane.add(new Label("Pocet mist:"), 0, 3);
        gridpane.add(txtPocetMist, 1, 3);
        txtPocetMist.setText(Integer.toString((int) editedLod.getPocetMist()));
        gridpane.add(new Label("Pocet plachet:"), 0, 4);
        gridpane.add(txtPlachty, 1, 4);   
        txtPlachty.setText(Integer.toString((int) editedLod.getPocetPlachet()));

//        switch (editedLod.getTyp()) {
//            case RYBARSKA:
//                cmBoxTypLodi.getSelectionModel().select(TypyLodi.RYBARSKA);
//                break;
//            case LODICKA:
//                cmBoxTypLodi.getSelectionModel().select(TypyLodi.LODICKA);
//                break;
//            case YACHTA:
//                cmBoxTypLodi.getSelectionModel().select(TypyLodi.YACHTA);
//                break;
//            
//        }

    }

    private void editujLod() {
        try {
            editedLod.setJmeno(txtNazev.getText());
            editedLod.setRychlost(Integer.parseInt(txtRychlost.getText()));
            editedLod.setPocetMist(Integer.parseInt(txtPocetMist.getText()));
            editedLod.setPocetPlachet(Integer.parseInt(txtPlachty.getText()));
            //editedLod.setTyp(cmBoxTypLodi.getValue());
            
        } catch (NumberFormatException ex) {
            GiveError();
        }

    }

    private void GiveError() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("ERROR");
        alert.setHeaderText("Spatne vlozena hodnota");
        alert.showAndWait();
    }

}

