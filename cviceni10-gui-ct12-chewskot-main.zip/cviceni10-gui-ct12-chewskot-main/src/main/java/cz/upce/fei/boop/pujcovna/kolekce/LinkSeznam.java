package cz.upce.fei.boop.pujcovna.kolekce;

import cz.upce.fei.boop.pujcovna.data.Lod;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class LinkSeznam<E> implements Seznam<E> {

    private Node<E> head = null;
    private Node<E> tail = null;
    private Node<E> current = null;
    private int size = 0;

    private static class Node<E> {

        private E hodnotaNode;
        private Node<E> dalsiNode;

        public Node(E hodnotaNode, Node<E> dalsiNode) {
            this.hodnotaNode = hodnotaNode;
            this.dalsiNode = dalsiNode;
        }

        public E hodnotaNode() {
            return hodnotaNode;
        }

        public Node<E> getDalsiNode() {
            return dalsiNode;
        }

        public void setDalsiNode(Node<E> dalsiNode) {
            this.dalsiNode = dalsiNode;
        }
    }

    @Override
    public void nastavPrvni() throws KolekceException {
        if (jePrazdny()) {
            throw new KolekceException();
        } else {
            current = head;
        }
    }

    public boolean dejAkt() {
        if (current == null) {
            return false;
        } else {
            return true;
        }
    }

    public int getSize() {
        return size;
    }

    public String[] printList() {
        Node<E> currents = head;
        String [] polozky = new String[getSize()];
        int i =0;
        while (currents != null) {
            //System.out.println(currents.hodnotaNode);
            polozky[i] = currents.hodnotaNode.toString();
            i++;
            currents = currents.dalsiNode;
        }
        return polozky;
    }

    @Override
    public void nastavPosledni() throws KolekceException {
        if (jePrazdny()) {
            throw new KolekceException();
        } else {
            current = tail;
        }
    }

    @Override
    public void dalsi() throws KolekceException {
        if (current == null || current.dalsiNode == null) {
            throw new KolekceException();
        }

        current = current.dalsiNode;
    }

    @Override
    public boolean jeDalsi() {
        if (current == null || jePrazdny()) {
            return false;
        }

        return current.dalsiNode != null;
    }

    @Override
    public void vlozPrvni(E data) {
        if (data == null) {
            throw new NullPointerException();
        } else {
            Node<E> vloz = new Node<>(data, head);
            if (head == null) {
                tail = vloz;
            } else {
                vloz.dalsiNode = head;
            }
            head = vloz;
            //current = head;
            size++;
        }
    }

    @Override
    public void vlozPosledni(E data) {

        if (data == null) {
            throw new NullPointerException();
        } else {
            Node<E> novyNode = new Node<>(data, null);
            if (jePrazdny()) {
                tail = novyNode;
                head = tail;
            } else {
                tail.dalsiNode = novyNode;
            }
            tail = novyNode;
            //current=tail;
            size++;
        }
    }

    @Override
    public void vlozZaAktualni(E data) throws KolekceException {
        if (data == null) {
            throw new NullPointerException();
        }
        if (jePrazdny() || current == null) {
            throw new KolekceException();
        }
        Node<E> novy = new Node<>(data, current.dalsiNode);
        current.dalsiNode = novy;
        if (current == tail) {
            tail = novy;
        }
        size++;

    }

    @Override
    public boolean jePrazdny() {
        return head == null;
    }

    @Override
    public E dejPrvni() throws KolekceException {
        if (jePrazdny() || head == null) {
            throw new KolekceException();
        }

        return head.hodnotaNode;

    }

    @Override
    public E dejPosledni() throws KolekceException {
        if (jePrazdny()) {
            throw new KolekceException();
        }
        return tail.hodnotaNode;

    }

    @Override
    public E dejAktualni() throws KolekceException {
        if (jePrazdny() || current == null) {
            throw new KolekceException();
        }
        return current.hodnotaNode();

    }

    @Override
    public E dejZaAktualnim() throws KolekceException {
        if (jePrazdny() || current == null || current.dalsiNode == null) {
            throw new KolekceException();
        }
        return current.dalsiNode.hodnotaNode;

    }

    @Override
    public E odeberPrvni() throws KolekceException {
        if (jePrazdny()) {
            tail = null;
            throw new KolekceException();
        }
        Node<E> odebirany = head;
        if (current == head) {
            current = null;
        }
        head = head.dalsiNode;
        size--;

        return odebirany.hodnotaNode;
    }

    @Override
    public E odeberPosledni() throws KolekceException {
        Node<E> odebirany;
        if (jePrazdny()) {
            throw new KolekceException();
        }
        if (current == tail) {
            current = null;
        }

        if (head == tail) {
            odebirany = head;
            head = null;
            tail = null;
        } else {
            Node<E> predPosledni = head;
            while (predPosledni.dalsiNode != tail) {
                predPosledni = predPosledni.dalsiNode;
            }
            odebirany = tail;
            tail = predPosledni;
            tail.dalsiNode = null;
        }

        size--;
        return odebirany.hodnotaNode;
    }

    public Lod Najdi(LinkSeznam<Lod> seznam, int id) {
    for (Lod lod : seznam) {
        if (lod.id == id) {
            
            return lod;
        }
    }
    return null;
    
}

    @Override
    public E odeberAktualni() throws KolekceException {
        if (jePrazdny() || current == null) {
            throw new KolekceException();
        }
        if (head == tail) {
            return odeberPosledni();
        }
        if (current == head) {
            E data = head.hodnotaNode;
            head = head.dalsiNode;
            current = null;
            size--;
            return data;
        }
        E data = current.hodnotaNode;
        Node<E> novy = head;
        while (novy.dalsiNode != current) {
            novy = novy.dalsiNode;
        }
        novy.dalsiNode = current.dalsiNode;
        if(current == tail)/// odsud az do toho dolu upraveno
        {
            tail=novy;
        }/// upraveno kdyztak smaz
        current = null;
        size--;
        return data;
    }

    @Override
    public E odeberZaAktualnim() throws KolekceException {
        if (jePrazdny()) {
            throw new KolekceException();
        }
        if (current == null) {
            throw new KolekceException();
        }
        if (current.dalsiNode == null) {
            throw new KolekceException();
        }
        Node<E> odebirany = current.dalsiNode;
        if (odebirany == tail) {
            odeberPosledni();
        } else {
            Node<E> temp = head;
            while (temp.dalsiNode != null) {
                if (temp.dalsiNode == odebirany) {
                    temp.dalsiNode = odebirany.dalsiNode;
                    break;
                }
                temp = temp.dalsiNode;
            }
            size--;
        }
        return odebirany.hodnotaNode;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public void zrus() {
        head = null;
        tail = null;
        current = null;
        size = 0;
    }

    @Override
    public Iterator<E> iterator() {
        Iterator<E> node = new Iterator<E>() {
            Node<E> p = head;

            @Override
            public boolean hasNext() {
                return p != null;
            }

            @Override
            public E next() {
                if (hasNext()) {
                    E data = p.hodnotaNode;
                    p = p.dalsiNode;
                    return data;
                }
                throw new NoSuchElementException();
            }
        };
        return node;
    }

}
