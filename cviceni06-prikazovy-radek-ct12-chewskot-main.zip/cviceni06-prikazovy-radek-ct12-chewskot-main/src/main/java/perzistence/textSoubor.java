/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package perzistence;

import static command.Commands.seznam;
import data.Lod;
import static data.Lod.citac;
import data.Lodicka;
import data.Rybarska;
import data.TypyLodi;
import data.Yachta;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import kolekce.KolekceException;

/**
 *
 * @author mojan
 */
public class textSoubor {

    public static boolean ZapisText() throws KolekceException {
        String fileName = "data.txt";
        try {
            FileWriter fileWriter = new FileWriter(fileName);
            PrintWriter printWriter = new PrintWriter(fileWriter);
            seznam.nastavPrvni();
            printWriter.println(citac);
            while (seznam.iterator().hasNext()) {
                Lod l = seznam.dejAktualni();
                printWriter.println(l.getId() + ";" + l.getJmeno() + ";" + l.getTyp() + ";" + l.getRychlost() + ";" + l.getPocetMist() + ";" + l.getAbs());
                if (!seznam.jeDalsi()) {
                    break;
                }
                seznam.dalsi();
            }

            printWriter.close();
            fileWriter.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static boolean VyctiText() throws KolekceException {
        try {
            BufferedReader br = new BufferedReader(new FileReader("data.txt"));
            String line = "";
            citac = Integer.parseInt(br.readLine());

            while ((line = br.readLine()) != null) {
                String[] data = line.split(";");
                int id = Integer.parseInt(data[0]);
                String jmeno = data[1];
                String typ = data[2];
                int rychlost = Integer.parseInt(data[3]);
                int pocetMist = Integer.parseInt(data[4]);
                int special = Integer.parseInt(data[5].substring(data[5].length() - 1));

                switch (typ) {
                    case "yachty":
                        Yachta n = new Yachta(jmeno, rychlost, pocetMist, special, TypyLodi.YACHTA);
                        seznam.vlozPosledni(n);
                        break;
                    case "lodicky":
                        Lodicka l = new Lodicka(jmeno, rychlost, pocetMist, special, TypyLodi.LODICKA);
                        seznam.vlozPosledni(l);
                        break;
                    case "rybarske lodi":
                        Rybarska r = new Rybarska(jmeno, rychlost, pocetMist, special, TypyLodi.RYBARSKA);
                        seznam.vlozPosledni(r);
                        break;

                }
                data = null;
            }
            return true;
        } catch (IOException e) {
            return false;
        }
    }
}
