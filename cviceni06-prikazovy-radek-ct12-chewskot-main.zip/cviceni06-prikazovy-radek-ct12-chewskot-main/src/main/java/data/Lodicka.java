/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author mojan
 */
public class lodicka extends Lod {

    public void setPocetPlachet(int pocetPlachet) {
        this.pocetPlachet = pocetPlachet;
    }

    @Override
    protected String additionalString() {
        return " pocet plachet= " + getPocetPlachet();
    }

    private int pocetPlachet;

    public lodicka(String jmeno, int rychlost, int pocetMist, int pocetPlachet, TypyLodi typ) {
        super(jmeno, rychlost, pocetMist, typ);
        if (pocetPlachet > 3) {
            System.out.println("neni mozne mit na lodicce vice nez tri plachty");

        } else if (pocetPlachet < 0) {
            System.out.println("lodicka nemuze byt bez plachet");
        } else {
            this.pocetPlachet = pocetPlachet;
        }

    }

    public lodicka() {

        try {

            if(!super.getChyba())
            {
                Scanner scan = new Scanner(System.in);
            super.setTyp(TypyLodi.LODICKA);

            System.out.println("zadejte pocet plachet");
            int k =Integer.parseInt(scan.nextLine());
            
            if (k > 3) {
                System.out.println("neni mozne mit na lodicce vice nez tri plachty");

            } else if (k < 0) {
                System.out.println("lodicka nemuze byt bez plachet");
            } else {
                this.pocetPlachet = k;
                System.out.println("uspesne jsi vlozil lodicku");
            }
            }
            

        } catch (NumberFormatException e) {
            System.out.println("nastala chyba v zadávání dat prosím opravte jí opetovným zadáním příkazu");
        }
    }

    public int getPocetPlachet() {
        return pocetPlachet;
    }

}
