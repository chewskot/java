/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

/**
 *
 * @author mojan
 */
public enum TypyLodi {
    LODICKA("lodicky"),
    RYBARSKA("rybarske lodi"),
    YACHTA("yachty");

    private final String nazev;

    private TypyLodi(String nazev) {
        this.nazev = nazev;
    }

    public String nazev() {
        return nazev;
    }

    @Override
    public String toString() {
        return nazev;
    }

}

