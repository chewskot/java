/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package command;

import kolekce.KolekceException;
import kolekce.LinkSeznam;
import java.util.Scanner;
import data.Lod;
import data.Lodicka;
import data.Rybarska;
import data.TypyLodi;
import data.Yachta;
import java.util.ArrayList;
import generator.Generator;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Iterator;
import perzistence.binar;
import perzistence.textSoubor;

/**
 *
 * @author mojan
 */
public class Commands {

    public static LinkSeznam<Lod> seznam = new LinkSeznam<>();

    public static void addDataToSeznam(Lod data) {
        seznam.vlozPosledni(data);
    }

    public static void main(String[] args) throws KolekceException {
        System.out.println("Vitej v programu pro spravu pujcovny lodi");
        String help = """
                 //      help, h     - výpis příkazů 
                 //      novy,no     - vytvoř novou instanci a vlož data za aktuální prvek
                 //      najdi,na,n  - najdi v seznamu data podle hodnoty nějakém atributu //podle id
                  //     odeber,od   - odeber data ze seznamu podle nějaké hodnoty atributu  //podle id
                 //      dej         - zobraz aktuální data v seznamu
                       edituj,edit - edituj aktuální data v seznamu
                 //      vyjmi       - vyjmi aktuální data ze seznamu
                 //      prvni,pr    - nastav jako aktuální první data v seznamu
                  //     dalsi,da    - přejdi na další data
                  //     posledni,po - přejdi na poslední data
                  //     pocet       - zobraz počet položek v seznamu
                  //    obnov       - obnov seznam data z binárního souboru
                  //     zalohuj     - zálohuj seznam dat do binárního souboru
                 //      vypis       - zobraz seznam dat
                 //    nactitext,nt- načti seznam data z textového souboru
                 //      uloztext,ut - ulož seznam data do textového souboru
                 //      generuj,g   - generuj náhodně data pro testování
                 //      zrus        - zruš všechny data v seznamu
                 //      exit        - ukončení programu
                      """;
        System.out.println(help);
        Scanner scan = new Scanner(System.in);
        String comm = "";
        while (!comm.equals("exit")) {

            comm = scan.nextLine();
            switch (comm) {
                case "h", "help" ->
                    System.out.println(help);
                case "novy", "no" -> {
                    System.out.println("budeme vytvaret lodicku,yachtu nebo rybarskou lod?");
                    System.out.println("pro lodicku napiste l nebo lodicka");
                    System.out.println("pro yachtu napiste y nebo yachta");
                    System.out.println("pro rybarskou lod napiste r nebo rybarska");

                    String n = scan.nextLine();
                    switch (n) {
                        case "l", "lodicka" -> {

                            Lodicka ll = new Lodicka();
                            seznam.vlozPosledni(ll);
                            if (ll.getChyba()) {
                                seznam.odeberPosledni();
                            }
                        }
                        case "y", "yachta" -> {

                            Yachta y = new Yachta();
                            seznam.vlozPosledni(y);
                            if (y.getChyba()) {
                                seznam.odeberPosledni();
                            }
                        }
                        case "r", "rybarska" -> {

                            Rybarska r = new Rybarska();
                            seznam.vlozPosledni(r);
                            if (r.getChyba()) {
                                seznam.odeberPosledni();
                            }
                        }
                        default -> {
                        }
                    }
                }
                case "vypis" -> {
                    if (seznam.getSize() == 0) {
                        System.out.println("seznam je prazdny");
                    } else {
                        seznam.printList();
                    }
                }
                case "g", "generuj" -> {
                    Generator g = new Generator();
                    g.rand();
                }
                case "dej" -> {
                    if (seznam.dejAkt()) {
                        System.out.println(seznam.dejAktualni());
                    }
                    else
                    {
                        System.out.println("bohuzel neni nastaven aktualni prvek");
                    }
                }
                case "vyjmi" -> {
                    if (seznam.dejAkt() == false) {
                        System.out.println("nelze  vyjimat jelikoz neni vybran aktualni prvek");
                    } else {
                        if (seznam.getSize() == 0) {
                            System.out.println("nelze vyjimat prvek, jelikoz seznam je prazdny");
                        } else {
                            System.out.println("byl vyjmut prvek " + seznam.odeberAktualni());
                        }
                    }
                }
                case "pocet" ->
                    System.out.println("pocet prvku v seznamu je " + seznam.getSize());
                case "prvni", "pr" -> {
                    if (seznam.getSize() == 0) {
                        System.out.println("nelze nastavit prvni prvek v prazdnem seznamu");
                    } else {
                        seznam.nastavPrvni();
                        System.out.println("ukazatel nastaven na " + seznam.dejAktualni());
                    }
                }
                case "dalsi", "da" -> {
                    if (seznam.getSize() < 2) {
                        System.out.println("nelze nastavit dalsi prvek v takto malem seznamu");
                    } else {
                        seznam.dalsi();
                        System.out.println("ukazatel nastaven na " + seznam.dejAktualni());
                    }
                }

                case "posledni", "po" -> {
                    if (seznam.getSize() == 0) {
                        System.out.println("nelze nastavit posledni prvek v prazdnem seznamu");
                    } else {
                        seznam.nastavPosledni();
                        System.out.println("ukazatel nastaven na " + seznam.dejAktualni());
                    }
                }
                case "edituj", "edit" -> {
                    if (seznam.getSize() == 0) {
                        System.out.println("nelze editovat prvek v prazdnem seznamu");
                    } else {
                        if (seznam.dejAkt()) {

                            seznam.dejAktualni().edituj();

                        } else {
                            System.out.println("nemuzeš editovat, jelikoz nebyl zvolen aktualni prvek");
                        }
                    }
                }
                case "odeber", "od" -> {
                    if (seznam.getSize() == 0) {
                        System.out.println("nelze odebrat prvek, jelikož seznam je prazdny");
                    } else {
                        if (seznam.dejAkt()) {

                            System.out.println(seznam.odeberAktualni() + "byl uspesne odebran");
                        } else {
                            System.out.println("neni nastaven aktualni prvek");
                        }
                    }
                }
                case "uloztext", "ut" -> {
                    if (seznam.getSize() == 0) {
                        System.out.println("je zbytecne ukladat prazdny seznam");
                    } else {
                        if (textSoubor.ZapisText()) {
                            System.out.println("seznam uspesne ulozen");
                        } else {
                            System.out.println("chyba pri zapisu");
                        }

                    }
                }
                case "nactitext", "nt" -> {

                    if (textSoubor.VyctiText()) {
                        System.out.println("seznam uspesne ulozen");
                    } else {
                        System.out.println("chyba pri nacteni");
                    }

                }

                case "najdi", "na","n" -> {
                    if (seznam.getSize() == 0) {
                        System.out.println("nelze hledat prvky v prázdném seznamu");
                    } else {
                        System.out.println("zadej ID pro nalezeni prvku");
                        String n = scan.nextLine();
                        Lod k = seznam.Najdi(seznam, Integer.parseInt(n));
                        if (k == null) {
                            System.out.println("pozadovena ID " + n + " neni v seznamu");
                        } else {
                            System.out.println(k);
                        }

                    }
                }
                case "zrus" -> {
                    if (seznam.getSize() == 0) {
                        System.out.println("seznam je jiz prazdny");
                    } else {
                        seznam.zrus();
                        System.out.println("seznam byl vyprazdnen");
                    }
                }
                case "zalohuj" -> {
                    binar.uloz();

                }
                case "obnov" -> {
                    binar.obnov();
                }
                default ->
                    System.out.println("tento prikaz nefunguje zkuste h nebo help pro funkcni prikazy");
            }

        }
        System.out.println("diky za pouzivani programu");
    }
}
