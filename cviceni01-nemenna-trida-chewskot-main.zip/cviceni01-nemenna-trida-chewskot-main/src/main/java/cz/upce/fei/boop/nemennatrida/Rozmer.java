package cz.upce.fei.boop.nemennatrida;

import java.util.Locale;

public class Rozmer {
private final double delka;
private final double sirka;
private final double vyska;
public static final double DIMENZE_MIN = 0.1;
public static final double DIMENZE_MAX = 100;
//<editor-fold defaultstate="collapsed" desc="Veřejné konstanty">
//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="Privátní konstanty ">
//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="Instanční proměnné/Atributy">
    // Stav objektu-u neměných objektu použít final
    /**
     * Délka rozměru jako celé číslo v centimetrech
     */
    /**
     * Šířka rozměru jako celé číslo v centimetrech
     */
    /**
     * Výška rozměru jako celé číslo v centimetrech
     */
//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="Konstruktory">
    /**
     * Konstruktor třídy zajistí definici (inicializaci) hodnot privátních
     * instančních proměnných
     *
     * @param delka rozměr délka v m
     * @param sirka rozměr šířka v m
     * @param vyska rozměr výška v m
     *
     * @throws MojeException se vystaví, když alespoň hodnota jednoho vstupního
     * parametruje mimo povolený rozsah
     */
    public Rozmer(final double delka, final double sirka, final double vyska) {
        this.delka = Math.round(delka*100);
        this.sirka = Math.round(sirka*100);
        this.vyska = Math.round(vyska*100);
        
        if(vyska<DIMENZE_MIN||sirka<DIMENZE_MIN||delka<DIMENZE_MIN)
        {
            throw new MojeException("Chyba");
        }
        
        if(vyska>DIMENZE_MAX||sirka>DIMENZE_MAX||delka>DIMENZE_MAX)
        {
            throw new MojeException("Chyba");
        }
                   
    }
//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="Přístupové metody ke stavu">
    /**
     * @return hodnota délky rozměru v m
     */
    public double getDelka() {
        return this.delka/100;
    }

    /**
     * @return hodnota šířky rozměru v m
     */
    public double getSirka() {
        return this.sirka/100;
    }

    /**
     * @return hodnota výšky rozměru v m
     */
    public double getVyska() {
       return this.vyska/100;
    }
//</editor-fold>

    @Override
    public String toString(){
    return String.format(Locale.ENGLISH,"Rozmer{delka=%5.2f,sirka=%5.2f,vyska=%5.2f}", this.getDelka(), this.getSirka(), this.getVyska());
    }
//<editor-fold defaultstate="collapsed" desc="Metody equals a hashCode">
//</editor-fold>
    
    @Override


    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + (int) ((int)this.delka ^ ((int)this.delka >>> 33));
        hash = 29 * hash + (int) ((int)this.sirka ^ ((int)this.sirka >>> 33));
        hash = 29 * hash + (int) ((int)this.vyska ^ ((int)this.vyska >>> 33));
        return hash;
        }
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
            }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Rozmer other = (Rozmer) obj;
        if (this.delka != other.delka) {
            return false;
        }
        if (this.sirka != other.sirka) {
            return false;
        }
        if (this.vyska != other.vyska) {
            return false;
        }
        return true;
        }
    
//<editor-fold defaultstate="collapsed" desc="Ostatní veřejné metody">
    /**
     * @param dimenze hodnota dílčího rozměru ke kontrole v metrech
     * @return vraci true, kdyz je dimenze v povoleném rozsahu
     */
    public static boolean kontrolaDimenze(double dimenze) {
        
        if(dimenze>=DIMENZE_MIN)
        {
            if(dimenze<=DIMENZE_MAX)
            {
                return true;
            }
            else
                
            {
                return false;
            }
        }
        else
        {
            return false;
        }
  
    }
//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="Privátní metody">
    //private static boolean check(double dimenze) {
       
    //}
//</editor-fold>
}
